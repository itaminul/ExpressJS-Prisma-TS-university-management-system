if(process.env.NODE_ENV !== 'production') {
  require('dotenv').config()
}
const express = require('express');
const  multer = require('multer')
const cookieParser = require('cookie-parser')
var parseurl = require('parseurl')
var session = require('express-session')
const path = require('path');
const passport = require('passport');
const passportConfig = require('./src/config/passport_555')
const cors = require('cors')
const http = require('http')
const bodyParser = require("body-parser");
const { ErrorHandler } = require('./src/middlewares/ErrorHandler');
const app =  express();
const authCheck = require('./src/middlewares/Authenticate')
const os = require("os");
app.use("/public", express.static("public"));


const oneDay = 1000 * 60 * 60 * 24;
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: true,
  saveUninitialized: false,
  // cookie: { maxAge: oneDay },
  cookie: {
    httpOnly: true,
    secure: true,
    sameSite: true, 
    // Session expires after 1 min of inactivity.
    maxAge: 24 * 60 * 60 * 1000
}
}))

// console.log("app session", session)
app.use(cors())
app.use(express.json())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser())
app.use(passport.initialize())
app.use(passport.session())

// passportConfig(passport)
// require('dotenv').config();
require('./src/middlewares/Jwt')(passport)

const port = process.env.PORT;
const databae = process.env.DATABASE_URL;
const hostname = process.env.HOST_NAME;

app.get('/api/profile', authCheck, (req, res , next) => {
  console.log("ddd", req.user)
  res.json({ success: true, "message": "Show successfully"})
  
})



/* image uplod*/
// SET STORAGE

const prisma = require('./prisma/index')
const generateRandomNumber = Math.floor(Math.random() * 10000000000);

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './public')
  },
  filename: function (req, file, cb) {
    // const fileName = Date.now() + '-' + file.originalname;
    // let target_file = req.files;
  // const generateRandomNumber = Math.floor(Math.random() * 10000000000);
    var fileName = file.originalname
    // const fileName = generateRandomNumber +'_'+new Date().getTime() + generateRandomNumber +'_'+file.originalname;
// console.log('destination', destination)

    cb(null, +"-" + fileName);
  }
})



var upload = multer({ 
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype == "image/png" ||
      file.mimetype == "image/jpg" ||
      file.mimetype == "image/jpeg"
    ) {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error("Only .png, .jpg and .jpeg format allowed!"));
    }
  },
 })

app.post("/api/createPres", authCheck ,upload.array('uploadImage', 10), async(req,res, next)=>{  



try {
  let { empOldId,empName,requestFor,deliveryDate,relationReqEmp,rxDate,ageYear,ageMonth,ageDay,realtionDateOfBirth,prescriptionGenDate,presImageList, medicineDeliveryDate,presGenerateChildList } = req.body;
  const url = req.protocol + "://" + req.get("host");
  // console.log("image outside", Math.floor(Math.random() * 10000000000))
  // console.log(" req.file.path", __dirname)
      // console.log("bbod", medicineDeliveryDate)
      // console.log("a", empName)
        let result = await prisma.presGenerateParent.create({
            data: {
                empOldId,
                empName,
                requestFor,
                relationReqEmp,
                deliveryDate,
                rxDate,
                ageYear,
                ageMonth,
                ageDay,
                realtionDateOfBirth,
                prescriptionGenDate: new Date().toLocaleDateString(),
                prescriptionGenTime: new Date().toLocaleTimeString(),
                medicineDeliveryDate: new Date(medicineDeliveryDate).toLocaleDateString(),
                // prescriptionImage: url+"/public/"+req.file.filename,
                facilitiesType:1,
                prescriptionStatus:0,
                presGenUrlStatus:1,
                orgId:req.user.orgId,
                presImage: {
                  create: JSON.parse(presImageList)
                },
                presGenerateChild: {
                    create: JSON.parse(presGenerateChildList)
                }
              }
        })
  res.json({ success: true, "message": "Save Successfully", result})
} catch (error) {
next(error)  
}
})




const router = require('./src/routes/indexRoute');

 app.use('/api', router)

 app.use(ErrorHandler)

app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
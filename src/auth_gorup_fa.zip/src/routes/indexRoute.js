const express = require('express')
const router = express.Router()
const userRouter = require('../routes/UsersRoutes')
const distributionRouter = require('./DistributionRoutes')//
const prescriptionRoute = require('../routes/PrescriptionRoutes')
const rxApprove = require('../routes/RxApproveRoutes')
const orderRouter = require('../routes/OrderRoutes')
const paideRouter = require('../routes/PaidRoute')
const dasboradRouter = require('../routes/DashbordRoutes')
router.use('/users', userRouter)
router.use('/distribution', distributionRouter)//
router.use('/prescription', prescriptionRoute)
router.use('/rxApprove', rxApprove)
router.use('/order', orderRouter)
router.use('/paid', paideRouter)
router.use('/dahsboard', dasboradRouter)
module.exports = router
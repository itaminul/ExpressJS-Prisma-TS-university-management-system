const express = require('express')
const auth = require('../middlewares/IsLoggedin')
const authCheck = require('../middlewares/Authenticate');
const { 
    rxcreateById,
     rxReceiveList,
     rxReceiveListById,
     medicineDelieryList,
     showMedicineListById,
     medicineDeliveryById,
     medicineReceive,
     medicineReceiveById,
     medicineReceiveList,
     totalMedInfoByMedicine,
     rxMedicinShowForHO,
     rxMedicinShowForHOById,
     mediReceive,
     medicineByIdName,
     mediDeliveryByHeadOffice,
     mediReceiveByHrDept,
     getHrMediId,
     } = require('../controller/RxApproveController');

const router = express.Router();

router.route('/createRxById/:id').post(authCheck, rxcreateById)
router.route('/').get(rxReceiveList)
router.route('/rxReceiveListById/:id').get(rxReceiveListById)

// Medicine receive
router.route('/medicineReceive').get(medicineReceive)
router.route('/medicineReceiveById/:id').get(medicineReceiveById)
router.route('/medicineReceiveList').get(medicineReceiveList)

// Medicine Delivery
router.route('/medicineDelieryList').get(medicineDelieryList)
router.route('/showMedicineListById/:id').get(showMedicineListById)
router.route('/medicineDeliveryById/:id').get(medicineDeliveryById)




router.route('/totalMedInfoByMedicine/:udProductCode').get(totalMedInfoByMedicine)


router.route('/rxMedicinShowForHO').get(authCheck, rxMedicinShowForHO)
router.route('/rxMedicinShowForHOById/:id').get(rxMedicinShowForHOById)


//medicine receive send from head office to hr
router.route('/mediReceive/:id').post(mediReceive)


//medicine deliery





router.route('/medicineByIdName/:id/:name').get(medicineByIdName)

router.route('/mediDeliveryByHeadOffice/').post(authCheck, mediDeliveryByHeadOffice)


router.route('/mediReceiveByHrDept/:id').post(mediReceiveByHrDept)
router.route('/getHrMediId/:id').get(getHrMediId)




module.exports = router
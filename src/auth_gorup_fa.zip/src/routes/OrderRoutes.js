const express = require('express')
// const auth = require('../middlewares/IsLoggedin')
const authCheck = require('../middlewares/Authenticate')
const {
    getMedicineOrderList,
    getDetailsByMedicine,
    rxMedicinForHO
} = require('../controller/OrderController')
const router = express.Router();
router.route('/getMedicineOrderList').get(authCheck, getMedicineOrderList)
router.route('/getDetailsByMedicine/:udProductCode').get(getDetailsByMedicine)
router.route('/rxMedicinForHO').post(authCheck,rxMedicinForHO)
module.exports = router
const express = require('express')
const router = express.Router();
const passportConfig = require('../../passport-config')
const {getAll, signup, login, userLogOut} = require('../controller/UsersController')
router.route('/').get(getAll)
router.route('/').post(signup)
router.route('/login').post(login)
router.route('/userLogOut').get(userLogOut)

module.exports = router
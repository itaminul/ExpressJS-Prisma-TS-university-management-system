const authCheck = require('../middlewares/Authenticate')
const express = require('express')
const {rxMedicinShowForHrDept, rxMedicinShowForHrReceive,mediReceiveByHROffice,medicineDistributionList,medicineDistributionById,medicineDelivery } = require('../controller/DistributionController')
const router = express.Router();
router.route('/rxMedicinShowForHrDept/').get(authCheck, rxMedicinShowForHrDept)
router.route('/rxMedicinShowForHrReceive/:id').get(rxMedicinShowForHrReceive)
router.route('/mediReceiveByHROffice/').post(authCheck, mediReceiveByHROffice)

router.route('/medicineDistributionList/').get(authCheck,medicineDistributionList)
router.route('/medicineDistributionById/:id').get(medicineDistributionById)
router.route('/medicineDelivery/:id').post(authCheck, medicineDelivery)
module.exports = router
const express = require('express')
const auth = require('../middlewares/IsLoggedin')
const authCheck = require('../middlewares/Authenticate')

const {
    getAll,
    prescriptionApproveByAti ,
    getPrescriptionById, 
    create, 
    update, 
    deleteSession, 
    prescriptionApprove, 
    prescriptionApproveByHeadOffice, 
    prescriptionApproveById,
    getAppvedMedListAfterReview,
    getAppvedMedListAfterReviewById
} = require('../controller/RequestProcesses')
const router = express.Router();

router.route('/').get(authCheck,getAll)

router.route('/prescriptionApproveByAti').get(prescriptionApproveByAti)
router.route('/getPrescriptionById/:id').get(getPrescriptionById)
router.route('/prescriptionApprove/:id').post(prescriptionApprove)
router.route('/prescriptionApproveByHeadOffice/:id').post(prescriptionApproveByHeadOffice)
router.route('/prescriptionApproveById/:id').post(authCheck, prescriptionApproveById)
router.route('/getAppvedMedListAfterReview').get(authCheck, getAppvedMedListAfterReview)
router.route('/getAppvedMedListAfterReviewById/:id').get(getAppvedMedListAfterReviewById)


router.route('/').post(create)
router.route('/:id').patch(update)
router.route('/:id').delete(deleteSession)
module.exports = router
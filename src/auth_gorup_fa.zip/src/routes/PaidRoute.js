const express = require('express')
const {getPatientsAfterMediDelivery,getPatientsOfAmountPaid,getPatientsOfAmountDue, getDueInformation, getnewIormation, getDueByEmployeeWise, employeList} = require('../controller/PaidReportController')
const router = express.Router();
router.route('/getPatientsAfterMediDelivery/').get(getPatientsAfterMediDelivery)
router.route('/getPatientsOfAmountPaid/:id').get(getPatientsOfAmountPaid)
router.route('/getPatientsOfAmountDue/:id').get(getPatientsOfAmountDue)
router.route('/getDueInformation').get(getDueInformation)
router.route('/getnewIormation').get(getnewIormation)

router.route('/getDueByEmployeeWise/:id').get(getDueByEmployeeWise)
router.route('/employeList').get(employeList)

module.exports = router
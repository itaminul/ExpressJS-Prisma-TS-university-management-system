const express = require('express')
// const auth = require('../middlewares/IsLoggedin')
const authCheck = require('../middlewares/Authenticate')
const {
    getAll
} = require('../controller/DashboardController')
const router = express.Router();
router.route('/').get(authCheck, getAll)
module.exports = router
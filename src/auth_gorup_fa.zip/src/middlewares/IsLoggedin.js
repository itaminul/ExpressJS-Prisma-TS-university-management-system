const jwt = require('jsonwebtoken')
const prisma = require('../../prisma/index')

//https://medium.com/@evangow/server-authentication-basics-express-sessions-passport-and-curl-359b7456003d
//https://codebun.com/login-and-logout-in-nodejs-expressjs-and-mongodb/
//https://www.section.io/engineering-education/session-management-in-nodejs-using-expressjs-and-express-session/

const isLoggedIn = async(req, res, next) => {
    try {
        
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        if (!token) {
            return res.status(403).send('A token is required for authentication');
          }

          try {
            const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_PRIVATE_KEY);

            // const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_PRIVATE_KEY);
         
            const userInfo = await prisma.user.findFirst({
                where: {
                    id: decoded.id
                },
                include: {
                   userToken: true
                }
            })
            if(!userInfo) {
                return res.status(401).send('Token Invalid');
                // res.json({ success: false, "message": "Token Invalied"})      
                // return res.status(401).send('Not');
            }

            req.userInfo = userInfo
            // req.token = token
            // next()
            // req.userName = userInfo;

          } catch (err) {
            if (err.name === "TokenExpiredError") {
                return res.status(401).send('Session timed out,please login again');
                // res.json({ success: false, "message": "Session timed out,please login again"})   
              } else if  (err.name === "JsonWebTokenError") {
                return res.status(401).send('User Inter Invalid Token');
                // res.json({ success: false, "message": "User Inter Invalid Token"})    
              } 
              return next();
          
            // return res.status(401).send('Not Authorized User Invalid Token');
          }
          req.user = userInfo;
          return next();
    } catch (error) {
        return next(error)        
    }
}

module.exports = isLoggedIn
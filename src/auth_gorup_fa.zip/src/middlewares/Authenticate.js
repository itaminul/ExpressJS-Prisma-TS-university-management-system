const passport = require("passport");
module.exports = (req, res, next) => {
    passport.authenticate('jwt', function(err, user, info) {
        if (err) return next(err);
        if (!user){

        
        if (info.name === 'TokenExpiredError') {
            return res.json({ success: true, "message": "Jwt Token Expired!"});
        } 

        if (info.name === 'JsonWebTokenError') {
            return res.json({ success: true, "message": "Invalid Token!"});
        }        

        return res.json({ success: true, "message": "Unauthorized Access - No Token Provided!"});
        
        }
        req.user = user;
        next();
    })(req, res, next);
};
function authenticationMiddleware() {
    return function (req, res, next) {
    if (req.isAuthenticated()) {
    console.log('auth ok')
    return next()
    }
    console.log('auth error')
    // res.redirect('/')
    }
    }
    module.exports=authenticationMiddleware
    
    // module.exports = authenticationMiddleware
    
    
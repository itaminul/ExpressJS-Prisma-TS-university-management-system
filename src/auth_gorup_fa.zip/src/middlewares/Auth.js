const jwt = require('jsonwebtoken')

const config = process.env

const verifyToken = (req, res, next) => {
    const token =  req.headers.authorization.split(' ')[1];
  
      console.log("new token", token)

        // decode token
  if (token) {
    // verifies secret and checks exp
    
    jwt.verify(token, config.ACCESS_TOKEN_PRIVATE_KEY, function(err, decoded) {
        if (err) {
            return res.status(401).json({"error": true, "message": 'Unauthorized access.' });
        }
      req.decoded = decoded;
      next();
    });


  } else {
    // if there is no token
    // return an error
    return res.status(403).send({
        "error": true,
        "message": 'No token provided.'
    });
  }


  };
  
  module.exports = verifyToken;
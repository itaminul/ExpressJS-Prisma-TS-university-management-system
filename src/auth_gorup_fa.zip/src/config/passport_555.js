const prisma = require('../../prisma/index')

const JwtStrategy = require('passport-jwt').Strategy,
    ExtractJwt = require('passport-jwt').ExtractJwt;
const opts = {}
opts.jwtFromRequest = ExtractJwt.fromAuthHeaderAsBearerToken();
opts.secretOrKey = 'secret';

module.exports = (passport) => {
    console.log("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYzZjFiYjM1ODQ2YThiNDZiNWMwOWZjMyIsInVzZXJOYW1lIjoiYWEiLCJyb2xlcyI6ImFkbWluIiwib3JnSWQiOiIxIiwiaWF0IjoxNjc2ODY3Njc3LCJleHAiOjE2NzY4NzEyNzd9.TamV_3e7obuCN3A-eVawVxMeJJ4iVfQum_WEPsLIg4Q")
    passport.use(new JwtStrategy(opts, async(jwt_payload, done) => {
        console.log("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYzZjFiYjM1ODQ2YThiNDZiNWMwOWZjMyIsInVzZXJOYW1lIjoiYWEiLCJyb2xlcyI6ImFkbWluIiwib3JnSWQiOiIxIiwiaWF0IjoxNjc2ODY3Njc3LCJleHAiOjE2NzY4NzEyNzd9.TamV_3e7obuCN3A-eVawVxMeJJ4iVfQum_WEPsLIg4Q")
        console.log("jwt_payload", jwt_payload.id)

        const userInfo = await prisma.user.findUnique({id: jwt_payload.id}, function(err, user) {
            // if (err) {
            //     return done(err, false);
            // }
            if (userInfo) {
                return done(null, userInfo);
            } else {
                console.log("eeeeeeeeeeeeeeeee")
                return done(null, false);
                // or you could create a new account
            }
        });
    }));
}
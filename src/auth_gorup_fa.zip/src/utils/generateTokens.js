const prisma = require('../../prisma/index')
const jwt = require('jsonwebtoken')

const generateTokens = async(userInfo) => {
    try {     
        const uId = userInfo.id     
        const payload = { 
            id: userInfo.id,
            roles: userInfo.roles, 
            userName: userInfo.userName, 
            email: userInfo.email, 
            orgId: userInfo.orgId
        }
        // console.log("payload user", payload)
        const accessToekn = jwt.sign(
            payload,
            process.env.ACCESS_TOKEN_PRIVATE_KEY,
            {expiresIn: "60m"}
        )

        const refreshToken = jwt.sign(
            payload,
            process.env.REFRESH_TOKEN_PRIVATE_KEY,
            {expiresIn: "30d"}
        )
        
/*
        const userToken = await prisma.userToken.findFirst({
            where: {
                userId: user.id
            }
        })
        if(userToken) await prisma.userToken.delete({
            where: {
                id: user.id
            }
        })

        await prisma.userToken.create({
            data: {
                userId: user.id,
                token: refreshToken
            }
        })
*/

// console.log("payload", payload)
      /*  const upsertUser = await prisma.userToken.upsert({
            where: {
                id: Number(userInfo.id)
            },
            update: {
                // userId: user.id,
                token: refreshToken
            },
            create: {
                userId: Number(userInfo.id),
                // userName: user.id,
                // email: user.id,
                token: accessToekn
            },
          })
*/

        // const saveToken = 
        return Promise.resolve({accessToekn, refreshToken})

    } catch (error) {
        return Promise.reject(error)
        
    }
}

module.exports = generateTokens
const prisma = require('../../prisma/index.js')
const jwt = require('jsonwebtoken')
const bcrypt =  require('bcrypt')
const generateTokens = require('../utils/generateTokens')
const passport = require('passport')
const initializePassport = require('../../passport-config')
// const { user } = require('../../prisma/index.js')
const generateToken = require('../utils/generateTokens')


    //https://kris101.medium.com/building-rest-api-in-nodejs-mongodb-passport-jwt-6c557332d4ca
    //https://blog.bitsrc.io/build-a-login-auth-app-with-mern-stack-part-1-c405048e3669
    //https://www.youtube.com/watch?v=l6uGc5ZNMN0
    //https://www.youtube.com/watch?v=-RCnNyD0L-s
    //https://www.djamware.com/post/6158fee27523f53fb5c1b2f4/authentication-role-permission-api-using-node-express-mysql
    
exports.getAll = async(req, res) => {
    try {
       const result = await prisma.user.findMany();
       res.send(result);
    } catch (error) {
        res.send(error)        
    }
}

exports.signup = async(req, res, next) => {
    try {

        const { name, userName, password, email, roles, orgId } = req.body      

        const findUser = await prisma.user.findFirst({
            where: {
                userName: userName
            }
        })


        if(findUser) {
            res.json({ success: true, "message": "User Already Exist", findUser });  
        }

        const salt = await bcrypt.genSalt(Number(process.env.SALT))

        const hashPassword = await bcrypt.hash(password, salt)

        const user = await prisma.user.create({
            data: {
                name,
                userName,
                password: hashPassword,
                email,
                roles,
                orgId,
                activeStatus: 1
            }
        })
        res.json({ success: true, "message": "Save Successfully", user });        
    } catch (err) {
        next(err)        
    }
}


exports.login = async(req, res, next) => {
    try {
        
        let { userName, password } = req.body;
        // console.log("userInfo ccc", password)
            // user name required validation
            if(!userName) {
                res.json({ success: false, "message": "Please provide username"}); 
            }
            //password required validation
            if(!password) {
                res.json({ success: false, "message": "Please provide password"}); 
            }

            const  userInfo = await prisma.user.findFirst({
                where: {
                    userName: userName
                }
            })

            // console.log("userInfo ccc", userInfo)

            const  usInfo = await prisma.user.findFirst({
                where: {
                    userName: userName
                }
            })

            // console.log("userInfo", userInfo)

        //verify password

        const verifiedPassword = await bcrypt.compare(password,userInfo.password)

        if(!verifiedPassword) {
            res.send({ error: true, "message": "Invalied Password"})

        }
        
        const {accessToekn} =await generateTokens(userInfo)
        // req.session.save();
        const {id, roles, orgId } = userInfo
            res.send({error: false, "message": "Login Successfully", token: 'bearer ' + accessToekn, id, roles, orgId})
    } catch (error) {
        next(error)
        
    }



}

/*

exports.login = async(req, res, next) => {
    try {
        let { userName, password } = req.body;

        if(!userName) {
            res.json({ success: false, "message": "Please provide username"}); 
        }
        if(!password) {
            res.json({ success: false, "message": "Please provide password"}); 
        }

        let userInfo = await prisma.user.findUnique({
            where: {
                userName: userName
            }
        })

        const isMatched = await bcrypt.compare(password,userInfo.password)

        if(!isMatched) {
            res.json({ success: false, "message": "Invalid Password"}); 

        }

        const accessToken = jwt.sign(
            payload,
            process.env.ACCESS_TOKEN_PRIVATE_KEY,
            {expiresIn: "2min"}
        )

        res.json({ accessToken: accessToken })

        // const { accessToken  } = await generateToken(userInfo)

        console.log("accessToken accessToken", accessToken)



        const payload = {
            id: user.id,
            userName: user.userName,
            roles: user.roles,
            orgId: user.orgId
        }

        res.status(200).json({
            error: false,
            accessToken,
            // refreshToken,
            message: "Logged in sucessfully",
        });

    } catch (error) {
        next(error)
        
    }


}
*/
exports.authenticateToken = (req, res, next) => {
    const token =  req.headers.authorization.split(' ')[1];
    if(token == null) return res.sendStatus(4001)
    jwt.verify(token, process.env.ACCESS_TOKEN_PRIVATE_KEY, (err, user) => {
        if(err) return res.sendStatus(403)
        req.user = user
        next()
    })

}

exports.userLogOut = async(req, res, next) => {
    try {
        // console.log('rrr', res)
    res.clearCookie('jwt');
    res.json({ success: true, "message": "Logout Successfully"});  
    } catch (error) {
        next(error)    
    }
}



function checkAuthenticated (req, res, next) {
    if(req.isAuthenticated()) {
        return next();
    }
}



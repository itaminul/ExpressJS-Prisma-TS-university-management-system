const prisma = require('../../prisma/index')
const path = require('path')
const multer = require('multer')
const uploadImage = require('../helper/Upload')

/* get all medicine without approved medicine*/

exports.getAll = async(req, res, next) => {
    try {
        // session=req.session
        // console.log("ssss", req.user)
        const totalPrescription = await prisma.presGenerateParent.aggregate({
            where: {
                prescriptionStatus: 0,
                activeStatus: 1,      
                orgId: req.user.orgId,
                NOT: {
                    completeStatus: 2,
                }
            },
            _count: {
                id: true
            }
        })

        
         let result = await prisma.presGenerateParent.findMany({
            where: {
                prescriptionStatus: 0,                
                activeStatus: 1,
                orgId: req.user.orgId,
                requestNo: null,
                NOT: {
                    completeStatus: 2,
                }
            },
            include: {
                presGenerateChild: {
                    where: {
                       NOT: {
                        prescMediAppStatus: 2
                       }
                    }
                }
            },
            include: {
                presImage: true
            }
         })
         res.json({ success: true, "message": "Show successfully", totalPrescription,result})
    } catch (error) {
        next(error)  
        
    }
}

exports.getOnlyRequestNo = async(req, res, next) => {
   try {
    const result = await prisma.presGenerateParent.findMany({
        where: {
            requestNo: {not: null},
            prescriptionStatus: 0
        },
        select: {
            requestNo: true
        }
    })
    res.json({ success: true, "message": "Show successfully", result})
} catch (error) {
    next(error)  
    
}

}

exports.getPrescriptionById = async(req, res, next) => {
    try {

        const totalMedicineCount = await prisma.presGenerateChild.groupBy({
            by: ['prescriptionId'],
            where: {
                prescriptionId: Number(req.params.id),
                NOT: {
                    prescMediAppStatus: 2
                   }
            },
            _count: {
                id: true
            }
        })

         let resultValue = await prisma.presGenerateParent.findMany({
            where: {
                id: Number(req.params.id),
                NOT: {
                    completeStatus: 2,
                }
            },
            include: {
                presGenerateChild: {
                    where: {
                        NOT: {
                         prescMediAppStatus: 2
                        }
                     }
                },
                presImage: true
            }
         })

         const [result] = resultValue;
         const [totalMedicine] = totalMedicineCount;

         res.json({ success: true, "message": "Show  successfully", totalMedicine, result})
    } catch (error) {
        next(error)  
        
    }
}

var storage = multer.diskStorage({
	destination: (req,file,cb)=> {
		cb(null,'./src/upload');
	},
	filename: (req,file,cb)=> {
		cb(null, Date.now() + file.originalname);
	}
});
var upload = multer({
	storage: storage,
	fileFilter: (req,file,cb)=> {
		// console.log('In File Filter');
			let ext = path.extname(file.originalname);
			if(ext == '.jpg' || ext == '.png' || ext == '.gif' || ext == '.jpeg') {
				cb(null,true);
			}
			else {
				cb('Only Images Are Allow', false);
			}
	}
})



exports.createPrescription = async(req, res, next) => {
    console.log("outside")
    try {
       // console.log("inside")
        let { empOldId,empName,requestFor,relationReqEmp,remarks,requestNo,prescriptionGenDate,presImageList, medicineDeliveryDate,presGenerateChildList } = req.body;
        const url = req.protocol + "://" + req.get("host");    

        //console.log("prescription data", req.body)    
              let result = await prisma.presGenerateParent.create({
                  data: {
                      empOldId,
                      empName,
                      requestFor,
                      relationReqEmp,
                      remarks,
                      requestNo,
                      prescriptionGenDate: new Date(prescriptionGenDate).toLocaleDateString(),
                      prescriptionGenTime: new Date().toLocaleTimeString(),
                      medicineDeliveryDate: new Date(medicineDeliveryDate).toLocaleDateString(),
                      // prescriptionImage: url+"/public/"+req.file.filename,
                      facilitiesType:1,
                      prescriptionStatus:0,
                      presGenUrlStatus:2,
                      orgId: req.user.orgId,
                      presImage: {
                        create: presImageList
                      },
                      presGenerateChild: {
                          create: presGenerateChildList
                      }
                    }
              })
        res.json({ success: true, "message": "Save Successfully", result})
      } catch (error) {
      next(error)  
      }
}


//create prescription by apps

exports.createPrescriptionByApps = async(req, res, next) => {
    //console.log("outside")
    try {
       // console.log("inside")
        let { empOldId,empName,requestFor,relationReqEmp,remarks,requestNo,completeStatus,prescriptionGenDate,presImageList, medicineDeliveryDate,presGenerateChildList } = req.body;
        const url = req.protocol + "://" + req.get("host");    

        //console.log("prescription data", req.body)    
              let result = await prisma.presGenerateParent.create({
                  data: {
                      empOldId,
                      empName,
                      requestFor,
                      relationReqEmp,
                      remarks,
                      requestNo,
                      prescriptionGenDate: new Date(prescriptionGenDate).toLocaleDateString(),
                      prescriptionGenTime: new Date().toLocaleTimeString(),
                      medicineDeliveryDate: new Date(medicineDeliveryDate).toLocaleDateString(),
                      // prescriptionImage: url+"/public/"+req.file.filename,
                      facilitiesType:1,
                      prescriptionStatus:0,
                      presGenUrlStatus:2,
                      completeStatus,
                      orgId: req.user.orgId,
                      presImage: {
                        create: presImageList
                      },
                      presGenerateChild: {
                          create: presGenerateChildList
                      }
                    }
              })
        res.json({ success: true, "message": "Save Successfully", result})
      } catch (error) {
      next(error)  
      }
}

exports.update = async(req, res, next) => {
    try {
        let { empOldId,empName,prescriptionGenDate,prescriptionImage,activeStatus,presGenerateChildList } = req.body;
        let data = await prisma.presGenerateParent.update({
            where: {
                id: Number(req.params.id)
            },
            data: {
                empOldId,
                empName,
                prescriptionGenDate: new Date(prescriptionGenDate),
                prescriptionImage,
                facilitiesType:1,
                prescriptionStatus:0,
                activeStatus:1,
                updatedBy: req.user.id,
                presGenerateChild: {
                    create: presGenerateChildList
                }
            }
        })
        res.json({ success: true, "message": "Update Successfully", data})
    } catch (error) {
        next(error)        
    }
}

exports.prescriptionApprove = async(req, res, next) => {
    try {
        let data = await prisma.presGenerateParent.update({
            where: {
                id: Number(req.params.id)
            },
            data: {                
                prescriptionStatus:1,
                prescriptionApproveDate: new Date().toLocaleDateString(),
                prescriptionApproveTime: new Date().toLocaleTimeString(),
                prescriptionApprovedBy:1
            }
        })
        res.json({ success: true, "message": "Approve Successfully", data})
    } catch (error) {
        next(error)        
    }
}


exports.prescriptionApproveById = async(req, res, next) => {
    try {
       
        const completeMedicine = await prisma.presGenerateParent.update({
            where: {
                id: Number(req.params.id)
            },
            data: {
                completeStatus: req.body.completeStatus

            }
        })

        const result = await prisma.presGenerateChild.updateMany({
            where: {
                id: {
                    in: req.body.medicinedChdId
                }
            },
            data: { 
                prescMediAppStatus:2,
                orgId: req.user.orgId,
                createdBy: req.user.id,
                completeStatus: req.body.completeStatus,
                presApproveAt: new Date().toLocaleDateString(),
                presApproveTime: new Date().toLocaleTimeString(),
                presApprovedBy:  req.user.id
            }
        })
        res.json({ success: true, "message": "Approve Successfully", result})
    } catch (error) {
        next(error)        
    }
}


exports.prescriptionApproveByAti = async(req, res, next) => {
    try {
         let result = await prisma.presGenerateParent.findMany({
            where: {
                prescriptionStatus: 1,
                activeStatus: 1
            },
            include: {
                presGenerateChild: true
            }
         })
         res.json({ success: true, "message": "Show successfully", result})
    } catch (error) {
        next(error)  
        
    }
}

/* show medicine list after reviewer approved partial or full quantity*/

exports.getAppvedMedListAfterReview = async(req, res, next) => {
    try {
        
        //group by
        const presId = await prisma.presGenerateChild.groupBy({
            by: ['prescriptionId'],
            where: {
                prescMediAppStatus: 2
            }         

        })    

        //get only value from array
        const mapToArray = (presId = []) => {
            const res = [];
            presId.forEach(function(obj,index){
                const key= Object.keys(obj);
               const value = parseInt(key, 10);
               res.push(obj[key]);
            });
            return res;
         };
  
         const gnValue = mapToArray(presId)
         //get id from object
         const patientId = [gnValue];
         const cPatientId = patientId.pop();
         
        const result = await prisma.presGenerateParent.findMany({
            where: {
                id: {in: cPatientId},
                NOT: {
                    prescriptionStatus:2
                }
                
            }
        })
        
        const totalPrescription = await prisma.presGenerateParent.aggregate({
            where: {
                id: {in: cPatientId}
            },
            _count: {
                id: true
            }
        })

        res.send({ success: true, "message": "Show Successfully", totalPrescription, result})        
    } catch (error) {
        next(error)
        
    }
}


exports.getAppvedMedListAfterReviewById = async(req, res, next) => {
    try {
        const totalMedicine = await prisma.presGenerateChild.aggregate({
            _count: {
                prescriptionId: true
            },
            where: {
                prescriptionId: Number(req.params.id),
                prescMediAppStatus:2
            }


        })
        const resultShow = await prisma.presGenerateParent.findMany({
            where: {
                id: Number(req.params.id)
            },
            include: {
                presGenerateChild: {
                    where: {
                        prescMediAppStatus:2
                    },
                    select: {
                    id:true,
                    prescriptionId:true,
                    udProductCode: true,
                    medicineName: true,
                    medicineQty: true,
                    prescMediAppStatus: true,
                    presApproveAt: true,
                    presApproveTime: true,
                    }
                },
                presImage: true
            }
        })

        const[result] = resultShow;
        res.send({ success: true, "message": "Show Successfully", totalMedicine ,result})        
    } catch (error) {
        next(error)
        
    }
}


exports.prescriptionApproveByHeadOffice = async(req, res, next) => {
    try {
        let data = await prisma.presGenerateParent.update({
            where: {
                id: Number(req.params.id)
            },
            data: {                
                prescriptionStatus:2,
                prescriptionApproveHOAt: new Date(),
                prescriptionApprovedByHO:1
            }
        })
        res.json({ success: true, "message": "Approve Successfully", data})
    } catch (error) {
        next(error)        
    }
}

exports.deleteSession = async(req, res, next) => {
    try {
        let data = await prisma.presGenerateParent.delete({
            where: {
                id: req.params.id
            }
        })
        res.json({ success: true, "message": "Delete Successfully", data})
    } catch (error) {
        next(error)        
    }
}
const prisma = require('../../prisma/index')

exports.rxcreateById = async(req, res, next) => {
    try {  
         const{prescriptionId,completeStatus, rxGenerateList} = req.body
         const result = await prisma.rxApproveParents.create({
            data: {
                prescriptionId,
                completeStatus,
                orgId:1,
                createdDate: new Date().toLocaleDateString(),
                createdTime: new Date().toLocaleTimeString(),
                rxApproveChild: {create:rxGenerateList}
            }
         })

         const upStatus = await prisma.presGenerateParent.update({
            where: {
                id: Number(req.params.id)
            },
            data: {
                prescriptionStatus:2,
            }
         })
         res.send({ success: true, "message": "Insert Successfully", result})        
    } catch (error) {
        next(error)
    }
}
//show list after head office approved

exports.rxReceiveList = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveParents.findMany({
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
        })
        res.send({ success: true, "message": "Show Successfully", result})
    } catch (error) {
        next(error)        
    }
}

//show details after head office approved by id
exports.rxReceiveListById = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveParents.findMany({
            where: {
                id: Number(req.params.id)

            },
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
        })
        res.send({ success: true, "message": "Show Successfully", result})
    } catch (error) {
        next(error)        
    }
}

//medicine receive list for ATI

exports.medicineReceive = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveParents.findMany({
            where: {
                NOT: {
                    rxMediReceiveStatus:2
                }
            },
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
        })
        res.send({ success: true, "message": "Show Successfully", result})
    } catch (error) {
        next(error)        
    }
}
//Medicine receive by ATI
exports.medicineReceiveById = async(req, res, next) => {
    try {  
         const result = await prisma.rxApproveParents.findMany({
            where: {
                id: Number(req.params.id)
            },
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
         })
         res.send({ success: true, "message": "Receive Successfully", result})        
    } catch (error) {
        next(error)
    }
}

//medicine receive list for ATI
exports.medicineReceiveList = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveParents.findMany({
            where: {
                NOT: {
                    rxMediReceiveStatus:2
                }
            },
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
        })
        res.send({ success: true, "message": "Show Successfully", result})
    } catch (error) {
        next(error)        
    }
}

// medicine delvery lis show for ATI
exports.medicineDelieryList = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveParents.findMany({
            where: {
                NOT: {
                    rxMediDelieryStatus:2
                }
            }
        })
        res.send({ success: true, "message": "Show Successfully", result})
    } catch (error) {
        next(error)        
    }
}

// show medicine for delvery by id of ATI
exports.showMedicineListById = async(req, res, next) => {
    try {  
         const result = await prisma.rxApproveParents.findMany({
            where: {
                id: req.params.id
            },
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
         })
         res.send({ success: true, "message": "Medicine Delivery Successfully", result})        
    } catch (error) {
        next(error)
    }
}

// Medicine delivery 
exports.medicineDeliveryById = async(req, res, next) => {
    try {  
         const{rxMediPaidStatus, prescriptionId,rxMedicineAmount} = req.body
         const result = await prisma.rxApproveParents.update({
            where: {
                id: req.params.id
            },
            data: {     
                prescriptionId,
                rxMediDelieryStatus:2,          
                rxMediPaidStatus,
                rxMedicineAmount,
                mediDeliveryDate: new Date().toLocaleDateString(),
                mediDeliveryTime: new Date().toLocaleTimeString()
            }
         })
         res.send({ success: true, "message": "Receive Successfully", result})        
    } catch (error) {
        next(error)
    }
}

exports.getMedicineOrderList = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveChild.groupBy({
            by:['medicineName'],
            where: {
                rxMedicineStatus:1
            },          
            select: {
                medicineName: true,
            },
            _sum: {
                medicineQty: true
            }
            
        })
        res.send({ success: true, "message": "Show Successfully", result});        
    } catch (error) {
        next(error)        
    }
}

exports.getDetailsByMedicine = async(req, res, next) => {
    try {
       
        const result = await prisma.rxApproveChild.findMany({
            where: {
                rxMedicineStatus:1,
                medicineName: req.params.mediName || 0
            },
            include: {
                rxApproveParents: true
            },
            include: {
                rxApproveParents: {
                    include: {
                        presGenerateParent: {
                            select: {
                            empOldId: true,
                            empName:true
                            }
                        }
                    }
                }
            }

        })
        res.send({ success: true, "message": "Show Successfully", result});        
    } catch (error) {
        next(error)        
    }
}

exports.totalMedInfoByMedicine = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveChild.groupBy({
            by:['medicineName'],
            where: {
                rxMedicineStatus:1
            },          
            select: {
                medicineName: true,
            }
            
        })
        const result2 = await prisma.rxApproveChild.findMany({
            where: {
                rxMedicineStatus:1,
                medicineName: req.params.mediName || 0
            },
            include: {
                rxApproveParents: true
            },
            include: {
                rxApproveParents: {
                    include: {
                        presGenerateParent: {
                            select: {
                            empOldId: true,
                            empName:true
                            }
                        }
                    }
                }
            }

        })



        const medicineInfo = await prisma.rxApproveChild.findMany({
          //  distinct:['medicineName'],
            where: {
                rxMedicineStatus:1,
                medicineName: req.params.mediName
            },          
            include: {
                rxApproveParents: true
            }
            
        })

        const totalMedicine = await prisma.rxApproveChild.groupBy({
            by:['medicineName'],
            where: {
                rxMedicineStatus:1,
                id: result2.id,
                medicineName: req.params.mediName
            },          
            select: {
                medicineName: true
            },
            _sum: {
                medicineQty: true
            }
            
        })
        res.send({ success: true, "message": "Show Successfully", medicineInfo, totalMedicine});        
    } catch (error) {
        next(error)        
    }
}



exports.rxMedicinForHO = async(req, res, next) => {
    try {
        console.log("rr", req.body)
        const{prescriptionId, totalMediQty, medicineInfo} = req.body
        const result = await prisma.rxMediReForHoParent.create({
           data: {
            prescriptionId:prescriptionId,
            totalMediQty: totalMediQty,
            orgId:1,
            rxMediReForHoChild: {create:medicineInfo}
           }
        })
      
        const allId = []; 
        medicineInfo.forEach(function(obj, index) {
        const sValue = Object.values(obj);
        allId.push(sValue[0])
        });

        console.log("allId", allId)

        const result2 = await prisma.rxApproveChild.updateMany({
            where: {
                id: { in: allId }    
            },
            data: {     
                rxMedicineStatus:2
            }
         })
         res.send({ success: true, "message": "Insert Successfully", result, result2})          
    } catch (error) {
        next(error);
    }
}



exports.rxMedicinShowForHO = async(req, res, next) => {
    try {

        
        const result = await prisma.rxMediReForHoParent.findMany({
            where: {
                rxMediReceiveStatus: 1,
                NOT: {
                    rxMediReceiveStatus: 2,
                    rxMediReceiveStatus: 3,
                }
            },
            include: {
                rxMediReForHoChild: true
            }
        })

        
        const resultSum = await prisma.rxMediReForHoParent.findMany({
            where: {
                rxMediDelieryStatus: 1
            },
            include: {
                rxMediReForHoChild: true
            }
        })

        const count1 = await prisma.rxMediReForHoParent.findMany({
            where: {
                rxMediReceiveStatus: 1,
            },
            select: {
                id: true,
                totalMediQty: true,
                rxMediReceiveStatus: true
            }
        })

        const count2 = await prisma.rxMediReForHoChild.groupBy({
            by: ['rxMediReHoId'],
            where: {
                rxMediReceiveStatus: 2
            },
            _sum: {
                totalMedicineQty: true
            }
        })

        

         res.send({ success: true, "message": "Insert Successfully", result, resultSum, count1, count2})          
    } catch (error) {
        next(error);
    }
}



exports.rxMedicinShowForHOById = async(req, res, next) => {
    try {      
        const count1 = await prisma.rxMediReForHoParent.findMany({
            where: {
                id: Number(req.params.id)
            },
            select: {
                totalMediQty: true
            }
        })

        const count2 = await prisma.rxMediReForHoChild.groupBy({
            by: ['rxMediReHoId'],
            where: {
                rxMediReHoId: Number(req.params.id),
                rxMediReceiveStatus: 2
            },
            _sum: {
                medicineReceiveQty: true
            }
        })
        
        // console.log('count1', count1[0].totalMediQty);
        // console.log('medicineReceiveQty', count2[0]._sum.medicineReceiveQty);
        // if(count1[0].totalMediQty == count2[0]._sum.medicineReceiveQty) {

        //     res.send({ success: true, "message": "Complete"})  

        // }else{
          
            const result = await prisma.rxMediReForHoParent.findMany({
                where: {
                    id: Number(req.params.id)
                },
                include: {
                    rxMediReForHoChild: {
                        where: {
                                rxMediReceiveStatus : 1
                            
                        }
                    }
                }
            })
            res.send({ success: true, "message": "Show Successfully", result, count1, count2})  
        

       

        /*
                const result = await prisma.rxMediReForHoChild.groupBy({
            by: ['medicineName'],
           _sum: {
               totalMedicineQty: true,
               amount: true,
               medicineReceiveQty: true
           },
           where: {
               rxMediReHoId: Number(req.params.id)
           }
       })   

        const result = await prisma.rxMediReForHoParent.findMany({
            where: {
                id: Number(req.params.id)
            },
            include: {
                rxMediReForHoChild: true
            }
        })


        const medicineReceive = await prisma.rxMediReForHoChild.groupBy({
            by: ['medicineName'],
            // by: ['prescriptionId'],
            _sum: {
                totalMedicineQty: true,
                amount: true,
                medicineReceiveQty: true
            },
            where: {
                rxMediReHoId: Number(req.params.id)
            }
        })    
        const result = await prisma.rxMediReForHoChild.groupBy({
             by: ['medicineName'],
            _sum: {
                totalMedicineQty: true,
                amount: true,
                medicineReceiveQty: true
            },
            where: {
                rxMediReHoId: Number(req.params.id)
            }
        })   
        const resultBack = await prisma.rxMediReForHoParent.findMany({

            where: {
                id: Number(req.params.id)
            },
            include: {
                rxMediReForHoChild: true
            }
        })

        */
             
    } catch (error) {
        next(error);
    }
}



exports.rxMedicinShowForHrReceive = async(req, res, next) => {
    try {   
        
        // console.log('count1', count1[0].totalMediQty);
        // console.log('medicineReceiveQty', count2[0]._sum.medicineReceiveQty);
        // if(count1[0].totalMediQty == count2[0]._sum.medicineReceiveQty) {

        //     res.send({ success: true, "message": "Complete"})  

        // }else{
          
            const result = await prisma.rxMediReForHoParent.findMany({
                where: {
                    id: Number(req.params.id)
                },
                include: {
                    rxMediReForHoChild: {
                        where: {
                            rxMediReHoId: Number(req.params.id),
                            rxMediReceiveStatus: 2
                        },
                    }
                }
            })
            res.send({ success: true, "message": "Show Successfully", result})  
        

       

        /*
                const result = await prisma.rxMediReForHoChild.groupBy({
            by: ['medicineName'],
           _sum: {
               totalMedicineQty: true,
               amount: true,
               medicineReceiveQty: true
           },
           where: {
               rxMediReHoId: Number(req.params.id)
           }
       })   

        const result = await prisma.rxMediReForHoParent.findMany({
            where: {
                id: Number(req.params.id)
            },
            include: {
                rxMediReForHoChild: true
            }
        })


        const medicineReceive = await prisma.rxMediReForHoChild.groupBy({
            by: ['medicineName'],
            // by: ['prescriptionId'],
            _sum: {
                totalMedicineQty: true,
                amount: true,
                medicineReceiveQty: true
            },
            where: {
                rxMediReHoId: Number(req.params.id)
            }
        })    
        const result = await prisma.rxMediReForHoChild.groupBy({
             by: ['medicineName'],
            _sum: {
                totalMedicineQty: true,
                amount: true,
                medicineReceiveQty: true
            },
            where: {
                rxMediReHoId: Number(req.params.id)
            }
        })   
        const resultBack = await prisma.rxMediReForHoParent.findMany({

            where: {
                id: Number(req.params.id)
            },
            include: {
                rxMediReForHoChild: true
            }
        })

        */
             
    } catch (error) {
        next(error);
    }
}


exports.mediReceive = async(req, res, next) => {
    try {

        const{medicineReceiveList, amount,medicineReceiveQty} = req.body;

 /*

        const ids = [];
        medicineReceiveList.forEach(function(obj, index) {
            const idValue = Object.values(obj);
            console.log("id value",idValue);
            ids.push(idValue[0]);
        
        })

        const mqty = [];
        medicineReceiveList.forEach(function(obj, index) {
            const idValue = Object.values(obj);
            console.log("id value",idValue);
            mqty.push(idValue[1]);
        
        })
        const qty = 10
        const mycon = [10.11]

        const dataList = [
            {where: {ids}, data: {medicineReceiveQty: mqty}},
            ];
        const dataList2 = [
                {where: {id:71}, data: {medicineReceiveQty: 20}},
                {where: {id:71}, data: {medicineReceiveQty: 21}},
                ];
    


            // const result = await (dataList.map((data) => prisma.rxMediReForHoChild.update(data)));
            const setValue = [];        
            dataList.map((a, b) => {
                const sValue = Object.values(a);
                // console.log("bbb", Object.values(a))
                setValue.push(sValue[1]);

            })
       */
        const result = await prisma.rxMediReForHoChild.update({  
                        where: {
                            id: Number(req.params.id)
                            //id: { in:  ids}
                        },
                        data: {
                            medicineReceiveQty: medicineReceiveQty,
                            amount,
                            rxMediReceiveStatus:3,
                            medicineReceiveBy: 1,
                            medicineReceiveDate: new Date().toLocaleDateString(),
                            medicineReceiveTime: new Date().toLocaleTimeString()                
                          
                        }              
               
        })              
        res.send({ success: true, "message": "Insert Successfully", result})     

    } catch (error) {
        next(error);        
    }
}


exports.mediDeliveryByHeadOffice = async(req, res, next) => {
    try {
        const{medicineReceiveList, multipleId,amount,medicineReceiveQty} = req.body;


 /*

        const ids = [];
        medicineReceiveList.forEach(function(obj, index) {
            const idValue = Object.values(obj);
            console.log("id value",idValue);
            ids.push(idValue[0]);
        
        })

        const mqty = [];
        medicineReceiveList.forEach(function(obj, index) {
            const idValue = Object.values(obj);
            console.log("id value",idValue);
            mqty.push(idValue[1]);
        
        })
        const qty = 10
        const mycon = [10.11]

        const dataList = [
            {where: {ids}, data: {medicineReceiveQty: mqty}},
            ];
        const dataList2 = [
                {where: {id:71}, data: {medicineReceiveQty: 20}},
                {where: {id:71}, data: {medicineReceiveQty: 21}},
                ];
    


            // const result = await (dataList.map((data) => prisma.rxMediReForHoChild.update(data)));
            const setValue = [];        
            dataList.map((a, b) => {
                const sValue = Object.values(a);
                // console.log("bbb", Object.values(a))
                setValue.push(sValue[1]);

            })
       */


        const result = await prisma.rxMediReForHoChild.updateMany({  
                        where: {
                            id: { in: req.body.rxMediChdId}
                        },
                        data: {
                            rxMediReceiveStatus:2,
                            medicineReceiveBy: 1,
                            medicineReceiveDate: new Date().toLocaleDateString(),
                            medicineReceiveTime: new Date().toLocaleTimeString()                
                          
                        }              
               
        })     
        
       const totalDelivery = await prisma.rxMediReForHoChild.findFirst({
            where: {
                id: { in: req.body.rxMediChdId}
            },
        })
        const getToDel = totalDelivery.rxMediReHoId;

        const totalQty = await prisma.rxMediReForHoParent.findFirst({
            where: {
                id: getToDel
            },
            select: {
                totalMediQty: true
            }
        })

        const totalDeli = await prisma.rxMediReForHoChild.groupBy({
            where: {
                rxMediReHoId: getToDel,
                rxMediReceiveStatus: 2
            },
            by:['rxMediReHoId'],
            _sum: {
                totalMedicineQty: true
            }
        })

        const sumTotalQty = totalQty.totalMediQty;
        const sumtotalDeli =  totalDeli[0]._sum.totalMedicineQty;   
        console.log("sumTotalQty", sumTotalQty)
        console.log("sumtotalDeli", sumtotalDeli)
        if(sumTotalQty === sumtotalDeli){

        const resultUp = await prisma.rxMediReForHoParent.update({  
            where: {
                id: getToDel
            },
            data: {
               rxMediReceiveStatus: 2            
              
            }              
   
})   
 }


        res.send({ success: true, "message": "Insert Successfully", result, totalDelivery})     

    } catch (error) {
        next(error);        
    }
}


exports.medicineDistributionList = async(req, res, next) => {
    try {
        const result = await prisma.rxMediReForHoParent.findMany({
            where: {
                rxMediReceiveStatus: 3
            },
            // where: { medicineDeliveryParent: { none: {} } },
            include: {
                rxMediReForHoChild: true
            }
        })
        res.send({ success: true, "message": "Show successfully", result})
    } catch (error) {
        next(error)
    }
}


exports.medicineDistributionById = async(req, res, next) => {
    try {

        // console.log("req.params.id", req.params.id)
        const resultNew = await prisma.rxMediReForHoChild.findMany({
            where: {
                rxMediReHoId: Number(req.params.id),
                rxMediReceiveStatus: 3
            }
        })

        const preId = []
        resultNew.map((object, index) => {
        const iValue = Object.values(object);
        console.log("Ivalue",iValue);
        preId.push(iValue[5])
            
        })
        console.log("ddd", preId)

        const presId = [resultNew.prescriptionId];
        // console.log(presId)
        const newPatientName = await prisma.presGenerateParent.findMany({
            where: {
                id: { in: preId}
            }
        })

        const result = await prisma.rxMediReForHoParent.findMany({
            where: {
                id: Number(req.params.id)
            },
            include: {
                rxApproveParents: true
            },
            include: {
                rxMediReForHoParent: true
            },
            include: {
                rxMediReForHoChild: {
                    where: {
                        rxMediReceiveStatus: 3
                    }
                },
                
            }
        })

        const patientName = await prisma.presGenerateParent.findMany({
            where: {
                id: result[0].rxMediReForHoChild[0].prescriptionId
            }
        })
        // const mergeData = Object.assign(patientName, result);
        const contcatea = result.concat(patientName);
        res.send({ success: true, "message": "Show successfully", resultNew, newPatientName, patientName,result, contcatea})
    } catch (error) {
        next(error)
    }
}


exports.medicineDelivery = async(req, res, next) => {
    try {
        const {rxMediReHoId,rxMediPaidStatus,paidAmount,rxDeliveryList} = req.body;
        const result = await prisma.medicineDeliveryParent.create({
            data: {
                rxMediReHoId,
                rxMediPaidStatus,
                paidAmount,
                mediDeliveryDate: new Date().toLocaleDateString(),
                mediDeliveryTime: new Date().toLocaleTimeString(),
                orgId: 1,  
                medicineDeliveryChild: { create: rxDeliveryList}
            }
        })
        res.send({ success: true, "message": "Insert successfully", result})
    } catch (error) {
        next(error)
    }
}

exports.medicineByIdName = async(req, res, next) => {
    try {
        const result = await prisma.rxMediReForHoChild.findMany({
            where: {
                rxMediReHoId: Number(req.params.id),
                medicineName: req.params.name
                }
        })
        
        res.send({ success: true, "message": "Show successfully", result})
    } catch (error) {
        next(error)
    }

}




exports.rxMedicinShowForHrDept = async(req, res, next) => {
    try {
                
        const result1 = await prisma.rxMediReForHoParent.findMany({
            where: {
                rxMediReceiveStatus: 1,
                NOT: {
                    rxMediReceiveStatus: 2,
                    rxMediReceiveStatus: 3,
                }
            }
        })


        const result1ddd = await prisma.rxMediReForHoParent.findMany({
            where: { 
                // where: { medicineDeliveryParent: { none: {} } },
                // rxMediReForHoChild: { none: {}} ,             
                    rxMediReceiveStatus: 2
                    // rxMediReForHoChild: { none: {}}               
            }
        })

        const result = await prisma.rxMediReForHoChild.findMany({
            where: {               
                    rxMediReceiveStatus: 2               
            }
        })


         res.send({ success: true, "message": "Insert Successfully", result1, result})          
    } catch (error) {
        next(error);
    }
}

exports.getHrMediId = async(req, res, next) => {
    try {
        const{medicineReceiveList, amount,medicineReceiveQty} = req.body;
        const result = await prisma.rxMediReForHoChild.findMany({  
                        where: {
                            id: Number(req.params.id),
                        }           
               
        })              
        res.send({ success: true, "message": "Show Successfully", result})     

    } catch (error) {
        next(error);        
    }
}

exports.mediReceiveByHrDept = async(req, res, next) => {
    try {
        console.log(" Number(req.params.id)",  Number(req.params.id))
        const{medicineReceiveList, amount,medicineReceiveQty} = req.body;
        const result = await prisma.rxMediReForHoChild.update({  
                        where: {
                            id: Number(req.params.id)
                            //id: { in:  ids}
                        },
                        data: {
                            // medicineReceiveQty: medicineReceiveQty,
                            // amount,
                            rxMediReceiveStatus:3,
                            medicineReceiveBy: 1,
                            medicineReceiveDate: new Date().toLocaleDateString(),
                            medicineReceiveTime: new Date().toLocaleTimeString()                
                          
                        }              
               
        })              
        res.send({ success: true, "message": "Insert Successfully", result})     

    } catch (error) {
        next(error);        
    }
}




exports.mediReceiveByHROffice = async(req, res, next) => {
    try {
        const{medicineReceiveList, multipleId,amount,medicineReceiveQty} = req.body;


 /*

        const ids = [];
        medicineReceiveList.forEach(function(obj, index) {
            const idValue = Object.values(obj);
            console.log("id value",idValue);
            ids.push(idValue[0]);
        
        })

        const mqty = [];
        medicineReceiveList.forEach(function(obj, index) {
            const idValue = Object.values(obj);
            console.log("id value",idValue);
            mqty.push(idValue[1]);
        
        })
        const qty = 10
        const mycon = [10.11]

        const dataList = [
            {where: {ids}, data: {medicineReceiveQty: mqty}},
            ];
        const dataList2 = [
                {where: {id:71}, data: {medicineReceiveQty: 20}},
                {where: {id:71}, data: {medicineReceiveQty: 21}},
                ];
    


            // const result = await (dataList.map((data) => prisma.rxMediReForHoChild.update(data)));
            const setValue = [];        
            dataList.map((a, b) => {
                const sValue = Object.values(a);
                // console.log("bbb", Object.values(a))
                setValue.push(sValue[1]);

            })
       */
    //   const id = [326,329]
    //   console.log("id", id)
        const result = await prisma.rxMediReForHoChild.updateMany({  
                        where: {
                            id: { in: req.body.rxMediChdId}
                        },
                        data: {
                            // medicineReceiveQty: medicineReceiveQty,
                           // amount,
                            rxMediReceiveStatus:3,
                            medicineReceiveBy: 1,
                            medicineReceiveDate: new Date().toLocaleDateString(),
                            medicineReceiveTime: new Date().toLocaleTimeString()                
                          
                        }              
               
        })     
        

        const totalDelivery = await prisma.rxMediReForHoChild.findFirst({
            where: {
                id: { in: req.body.rxMediChdId}
            },
        })
        const getToDel = totalDelivery.rxMediReHoId;

        const totalQty = await prisma.rxMediReForHoParent.findFirst({
            where: {
                id: getToDel
            },
            select: {
                totalMediQty: true
            }
        })

        const totalDeli = await prisma.rxMediReForHoChild.groupBy({
            where: {
                rxMediReHoId: getToDel,
                rxMediReceiveStatus: 3
            },
            by:['rxMediReHoId'],
            _sum: {
                totalMedicineQty: true
            }
        })

        const sumTotalQty = totalQty.totalMediQty;
        const sumtotalDeli =  totalDeli[0]._sum.totalMedicineQty;   
        console.log("sumTotalQty", sumTotalQty)
        console.log("sumtotalDeli", sumtotalDeli)
        if(sumTotalQty === sumtotalDeli){

        const resultUp = await prisma.rxMediReForHoParent.update({  
            where: {
                id: getToDel
            },
            data: {
               rxMediReceiveStatus: 3            
              
            }              
   
})   
 }



        res.send({ success: true, "message": "Insert Successfully", result, totalDelivery})     

    } catch (error) {
        next(error);        
    }
}

/*
exports.medicineDelivery = async(req, res, next) => {
    try {
        const {rxMediDelieryStatus,rxDeliveryList} = req.body;
        const arr=[]
        rxDeliveryList.forEach(function(a,b) {
            const show = Object.values(a)
            arr.push(show[0])
        })
        const result = await prisma.rxMediReForHoParent.update({
            where: {
                id: Number(req.params.id)
            },

            data: {
                rxMediDelieryStatus,
                rxMediReForHoChild: {
                    updateMany: [
                        {
                            where: {
                                id: { in: arr}
                            },
                            data: {
                                rxMediDelieryStatus
                            },
                        }
                       
                    ],
                }
            },
        })
        res.send({ success: true, "message": "Insert successfully", result})
    } catch (error) {
        next(error)
    }
}*/
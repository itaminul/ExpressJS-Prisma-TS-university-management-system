const prisma = require('../../prisma/index')


//Medicine receive by hr
exports.getAll = async(req, res, next) => {
   try {
    res.send({ success: true, "message": "Dashbord"})   
   } catch (error) {
    next(error);  
   } 
}

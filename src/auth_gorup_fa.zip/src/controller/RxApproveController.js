const prisma = require('../../prisma/index')

exports.rxcreateById = async(req, res, next) => {
    try {  
         const{prescriptionId,completeStatus, rxGenerateList} = req.body
        //  console.log("rxGenerateList", rxGenerateList)
         const result = await prisma.rxApproveParents.create({
            data: {
                prescriptionId,
                completeStatus,
                orgId: req.user.orgId,
                createdDate: new Date().toLocaleDateString(),
                createdTime: new Date().toLocaleTimeString(),
                createdBy: req.user.id,
                rxApproveChild: {create:rxGenerateList}
            }
         })
         
        const upStatus = await prisma.presGenerateParent.update({
            where: {
                id: Number(req.params.id)
            },
            data: {
                prescriptionStatus:2,
            }
         })
         res.send({ success: true, "message": "Insert Successfully", result})        
    } catch (error) {
        next(error)
    }
}
//show list after head office approved

exports.rxReceiveList = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveParents.findMany({
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
        })
        res.send({ success: true, "message": "Show Successfully", result})
    } catch (error) {
        next(error)        
    }
}

//show details after head office approved by id
exports.rxReceiveListById = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveParents.findMany({
            where: {
                id: Number(req.params.id)

            },
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
        })
        res.send({ success: true, "message": "Show Successfully", result})
    } catch (error) {
        next(error)        
    }
}

//medicine receive list for ATI

exports.medicineReceive = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveParents.findMany({
            where: {
                NOT: {
                    rxMediReceiveStatus:2
                }
            },
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
        })
        res.send({ success: true, "message": "Show Successfully", result})
    } catch (error) {
        next(error)        
    }
}
//Medicine receive by ATI
exports.medicineReceiveById = async(req, res, next) => {
    try {  
         const result = await prisma.rxApproveParents.findMany({
            where: {
                id: Number(req.params.id)
            },
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
         })
         res.send({ success: true, "message": "Receive Successfully", result})        
    } catch (error) {
        next(error)
    }
}

//medicine receive list for ATI
exports.medicineReceiveList = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveParents.findMany({
            where: {
                NOT: {
                    rxMediReceiveStatus:2
                }
            },
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
        })
        res.send({ success: true, "message": "Show Successfully", result})
    } catch (error) {
        next(error)        
    }
}

// medicine delvery lis show for ATI
exports.medicineDelieryList = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveParents.findMany({
            where: {
                NOT: {
                    rxMediDelieryStatus:2
                }
            }
        })
        res.send({ success: true, "message": "Show Successfully", result})
    } catch (error) {
        next(error)        
    }
}

// show medicine for delvery by id of ATI
exports.showMedicineListById = async(req, res, next) => {
    try {  
         const result = await prisma.rxApproveParents.findMany({
            where: {
                id: req.params.id
            },
            include: {
                rxApproveChild: true,
                presGenerateParent: true
            }
         })
         res.send({ success: true, "message": "Medicine Delivery Successfully", result})        
    } catch (error) {
        next(error)
    }
}

// Medicine delivery 
exports.medicineDeliveryById = async(req, res, next) => {
    try {  
         const{rxMediPaidStatus, prescriptionId,rxMedicineAmount} = req.body
         const result = await prisma.rxApproveParents.update({
            where: {
                id: req.params.id
            },
            data: {     
                prescriptionId,
                rxMediDelieryStatus:2,          
                rxMediPaidStatus,
                rxMedicineAmount,
                mediDeliveryDate: new Date().toLocaleDateString(),
                mediDeliveryTime: new Date().toLocaleTimeString()
            }
         })
         res.send({ success: true, "message": "Receive Successfully", result})        
    } catch (error) {
        next(error)
    }
}

exports.totalMedInfoByMedicine = async(req, res, next) => {
    try {
        const result = await prisma.rxApproveChild.groupBy({
            by:['medicineName'],
            where: {
                rxMedicineStatus:1
            },          
            select: {
                medicineName: true,
        }
            
        })
        const result2 = await prisma.rxApproveChild.findMany({
            where: {
                rxMedicineStatus:1,
                udProductCode: req.params.udProductCode || 0
            },
            include: {
                rxApproveParents: true
            },
            include: {
                rxApproveParents: {
                    include: {
                        presGenerateParent: {
                            select: {
                            empOldId: true,
                            empName:true
                            }
                        }
                    }
                }
            }

        })



        const medicineInfo = await prisma.rxApproveChild.findMany({
          //  distinct:['medicineName'],
            where: {
                rxMedicineStatus:1,
                udProductCode: req.params.udProductCode
            },          
            include: {
                rxApproveParents: true
            }
            
        })

        const totalMedicine = await prisma.rxApproveChild.groupBy({
            by:['udProductCode','medicineName'],
            where: {
                rxMedicineStatus:1,
                id: result2.id,
                udProductCode: req.params.udProductCode
            },          
            select: {
                udProductCode: true,
                medicineName: true
            },
            _sum: {
                medicineQty: true
            }
            
        })
        res.send({ success: true, "message": "Show Successfully", medicineInfo, totalMedicine});        
    } catch (error) {
        next(error)        
    }
}



exports.rxMedicinShowForHO = async(req, res, next) => {
    try {

        
        const result = await prisma.rxMediReForHoParent.findMany({
            where: {
                rxMediReceiveStatus: 1,
                NOT: {
                    rxMediReceiveStatus: 2,
                    rxMediReceiveStatus: 3,
                }
            },
            include: {
                rxMediReForHoChild: true
            }
        })

        
        const resultSum = await prisma.rxMediReForHoParent.findMany({
            where: {
                rxMediDelieryStatus: 1
            },
            include: {
                rxMediReForHoChild: true
            }
        })

        const count1 = await prisma.rxMediReForHoParent.findMany({
            where: {
                rxMediReceiveStatus: 1,
            },
            select: {
                id: true,
                totalMediQty: true,
                rxMediReceiveStatus: true
            }
        })

        const count2 = await prisma.rxMediReForHoChild.groupBy({
            by: ['rxMediReHoId'],
            where: {
                rxMediReceiveStatus: 2
            },
            _sum: {
                totalMedicineQty: true
            }
        })

        const sumOrder = await prisma.rxMediReForHoParent.groupBy({
            orderBy: {
                id: 'asc'
            },
            by: ['id'],
            _sum: {
                totalMediQty: true
            }
        })
        const getId = await prisma.rxMediReForHoParent.findMany()

        const sumOrderChid = await prisma.rxMediReForHoChild.groupBy({
            by: ['rxMediReHoId'],
            where: {
                rxMediReceiveStatus: {in: [2,3]},
                rxMediReHoId: getId.id
            },
            _sum: {
                totalMedicineQty: true
            }
        })

        

         res.send({ success: true, "message": "Insert Successfully", result, resultSum, count1, count2, sumOrder, sumOrderChid})          
    } catch (error) {
        next(error);
    }
}



exports.rxMedicinShowForHOById = async(req, res, next) => {
    try {      
        // console.log("req.params.id", req.params.id)
        const count1 = await prisma.rxMediReForHoParent.findMany({
            where: {
                id: Number(req.params.id)
            },
            select: {
                totalMediQty: true
            }
        })

        const count2 = await prisma.rxMediReForHoChild.groupBy({
            by: ['rxMediReHoId'],
            where: {
                rxMediReHoId: Number(req.params.id),
                rxMediReceiveStatus: 2
            },
            _sum: {
                medicineReceiveQty: true
            }
        })
        
        // console.log('count1', count1[0].totalMediQty);
        // console.log('medicineReceiveQty', count2[0]._sum.medicineReceiveQty);
        // if(count1[0].totalMediQty == count2[0]._sum.medicineReceiveQty) {

        //     res.send({ success: true, "message": "Complete"})  

        // }else{
          
            const result = await prisma.rxMediReForHoParent.findMany({
                where: {
                    id: Number(req.params.id)
                },
                include: {
                    rxMediReForHoChild: {
                        where: {
                                rxMediReceiveStatus : 1
                            
                        }
                    }
                }
            })
            res.send({ success: true, "message": "Show Successfully", result, count1, count2})  
        

       

        /*
        const result = await prisma.rxMediReForHoChild.groupBy({
            by: ['medicineName'],
           _sum: {
               totalMedicineQty: true,
               amount: true,
               medicineReceiveQty: true
           },
           where: {
               rxMediReHoId: Number(req.params.id)
           }
       })   
        const result = await prisma.rxMediReForHoParent.findMany({
            where: {
                id: Number(req.params.id)
            },
            include: {
                rxMediReForHoChild: true
            }
        })
        const medicineReceive = await prisma.rxMediReForHoChild.groupBy({
            by: ['medicineName'],
            // by: ['prescriptionId'],
            _sum: {
                totalMedicineQty: true,
                amount: true,
                medicineReceiveQty: true
            },
            where: {
                rxMediReHoId: Number(req.params.id)
            }
        })    
        const result = await prisma.rxMediReForHoChild.groupBy({
             by: ['medicineName'],
            _sum: {
                totalMedicineQty: true,
                amount: true,
                medicineReceiveQty: true
            },
            where: {
                rxMediReHoId: Number(req.params.id)
            }
        })   
        const resultBack = await prisma.rxMediReForHoParent.findMany({

            where: {
                id: Number(req.params.id)
            },
            include: {
                rxMediReForHoChild: true
            }
        })

        */
             
    } catch (error) {
        next(error);
    }
}



exports.mediReceive = async(req, res, next) => {
    try {

        const{medicineReceiveList, amount,medicineReceiveQty} = req.body;

 /*

        const ids = [];
        medicineReceiveList.forEach(function(obj, index) {
            const idValue = Object.values(obj);
            console.log("id value",idValue);
            ids.push(idValue[0]);
        
        })

        const mqty = [];
        medicineReceiveList.forEach(function(obj, index) {
            const idValue = Object.values(obj);
            console.log("id value",idValue);
            mqty.push(idValue[1]);
        
        })
        const qty = 10
        const mycon = [10.11]

        const dataList = [
            {where: {ids}, data: {medicineReceiveQty: mqty}},
            ];
        const dataList2 = [
                {where: {id:71}, data: {medicineReceiveQty: 20}},
                {where: {id:71}, data: {medicineReceiveQty: 21}},
                ];
    


            // const result = await (dataList.map((data) => prisma.rxMediReForHoChild.update(data)));
            const setValue = [];        
            dataList.map((a, b) => {
                const sValue = Object.values(a);
                // console.log("bbb", Object.values(a))
                setValue.push(sValue[1]);

            })
       */
        const result = await prisma.rxMediReForHoChild.update({  
                        where: {
                            id: Number(req.params.id)
                            //id: { in:  ids}
                        },
                        data: {
                            medicineReceiveQty: medicineReceiveQty,
                            amount,
                            rxMediReceiveStatus:3,
                            medicineReceiveBy: 1,
                            medicineReceiveDate: new Date().toLocaleDateString(),
                            medicineReceiveTime: new Date().toLocaleTimeString()                
                          
                        }              
               
        })              
        res.send({ success: true, "message": "Insert Successfully", result})     

    } catch (error) {
        next(error);        
    }
}


exports.mediDeliveryByHeadOffice = async(req, res, next) => {
    try {
        const{medicineReceiveList, multipleId,amount,medicineReceiveQty} = req.body;


 /*

        const ids = [];
        medicineReceiveList.forEach(function(obj, index) {
            const idValue = Object.values(obj);
            console.log("id value",idValue);
            ids.push(idValue[0]);
        
        })
        const mqty = [];
        medicineReceiveList.forEach(function(obj, index) {
            const idValue = Object.values(obj);
            console.log("id value",idValue);
            mqty.push(idValue[1]);
        
        })
        const qty = 10
        const mycon = [10.11]

        const dataList = [
            {where: {ids}, data: {medicineReceiveQty: mqty}},
            ];
        const dataList2 = [
                {where: {id:71}, data: {medicineReceiveQty: 20}},
                {where: {id:71}, data: {medicineReceiveQty: 21}},
                ];
    


            // const result = await (dataList.map((data) => prisma.rxMediReForHoChild.update(data)));
            const setValue = [];        
            dataList.map((a, b) => {
                const sValue = Object.values(a);
                // console.log("bbb", Object.values(a))
                setValue.push(sValue[1]);

            })
       */


        const result = await prisma.rxMediReForHoChild.updateMany({  
                        where: {
                            id: { in: req.body.rxMediChdId}
                        },
                        data: {
                            rxMediReceiveStatus:2,
                            medicineReceiveBy: 1,
                            medicineReceiveDate: new Date().toLocaleDateString(),
                            medicineReceiveTime: new Date().toLocaleTimeString()                
                          
                        }              
               
        })     
        
       const totalDelivery = await prisma.rxMediReForHoChild.findFirst({
            where: {
                id: { in: req.body.rxMediChdId}
            },
        })
        const getToDel = totalDelivery.rxMediReHoId;

        const totalQty = await prisma.rxMediReForHoParent.findFirst({
            where: {
                id: getToDel
            },
            select: {
                totalMediQty: true
            }
        })

        const totalDeli = await prisma.rxMediReForHoChild.groupBy({
            where: {
                rxMediReHoId: getToDel,
                // rxMediReceiveStatus: 2
                rxMediReceiveStatus: {in: [2,3]}
            },
            by:['rxMediReHoId'],
            _sum: {
                totalMedicineQty: true
            }
        })

        console.log("sum a", totalDeli)

        const sumTotalQty = totalQty.totalMediQty;
        const sumtotalDeli =  totalDeli[0]._sum.totalMedicineQty;   
        console.log("sumTotalQty", sumTotalQty)
        console.log("sumtotal Deli", sumtotalDeli)
        if(sumTotalQty === sumtotalDeli){

        const resultUp = await prisma.rxMediReForHoParent.update({  
            where: {
                id: getToDel
            },
            data: {
               rxMediReceiveStatus: 2            
              
            }              
   
})   
 }
  res.send({ success: true, "message": "Insert Successfully", result, totalDelivery})     

    } catch (error) {
        next(error);        
    }
}


exports.medicineByIdName = async(req, res, next) => {
    try {
        const result = await prisma.rxMediReForHoChild.findMany({
            where: {
                rxMediReHoId: Number(req.params.id),
                medicineName: req.params.name
                }
        })
        
        res.send({ success: true, "message": "Show successfully", result})
    } catch (error) {
        next(error)
    }

}




exports.getHrMediId = async(req, res, next) => {
    try {
        const{medicineReceiveList, amount,medicineReceiveQty} = req.body;
        const result = await prisma.rxMediReForHoChild.findMany({  
                        where: {
                            id: Number(req.params.id),
                        }           
               
        })              
        res.send({ success: true, "message": "Show Successfully", result})     

    } catch (error) {
        next(error);        
    }
}

exports.mediReceiveByHrDept = async(req, res, next) => {
    try {
        console.log(" Number(req.params.id)",  Number(req.params.id))
        const{medicineReceiveList, amount,medicineReceiveQty} = req.body;
        const result = await prisma.rxMediReForHoChild.update({  
                        where: {
                            id: Number(req.params.id)
                            //id: { in:  ids}
                        },
                        data: {
                            // medicineReceiveQty: medicineReceiveQty,
                            // amount,
                            rxMediReceiveStatus:3,
                            medicineReceiveBy: 1,
                            medicineReceiveDate: new Date().toLocaleDateString(),
                            medicineReceiveTime: new Date().toLocaleTimeString()                
                          
                        }              
               
        })              
        res.send({ success: true, "message": "Insert Successfully", result})     

    } catch (error) {
        next(error);        
    }
}



/*
exports.medicineDelivery = async(req, res, next) => {
    try {
        const {rxMediDelieryStatus,rxDeliveryList} = req.body;
        const arr=[]
        rxDeliveryList.forEach(function(a,b) {
            const show = Object.values(a)
            arr.push(show[0])
        })
        const result = await prisma.rxMediReForHoParent.update({
            where: {
                id: Number(req.params.id)
            },

            data: {
                rxMediDelieryStatus,
                rxMediReForHoChild: {
                    updateMany: [
                        {
                            where: {
                                id: { in: arr}
                            },
                            data: {
                                rxMediDelieryStatus
                            },
                        }
                       
                    ],
                }
            },
        })
        res.send({ success: true, "message": "Insert successfully", result})
    } catch (error) {
        next(error)
    }
}*/
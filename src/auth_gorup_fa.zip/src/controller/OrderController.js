const prisma = require('../../prisma/index')
exports.getMedicineOrderList = async(req, res, next) => {
    try {
        const resultCode = await prisma.rxApproveChild.groupBy({
            by:['udProductCode'],
            where: {
                rxMedicineStatus:1,
                orgId: req.user.orgId
            },          
            select: {
                udProductCode: true
            },
            _sum: {
                medicineQty: true
            }
            
        })

        const medicine = await prisma.rxApproveChild.findMany({
            distinct: ['medicineName'],
            where: {
                udProductCode: resultCode.udProductCode
            },          
            select: {
                udProductCode: true,
                medicineName: true,
            }
            
        })



        const result = await prisma.rxApproveChild.groupBy({
            by:['medicineName'],
            where: {
                rxMedicineStatus:1,
                orgId: req.user.orgId
            },          
            select: {
                medicineName: true,
            },
            _sum: {
                medicineQty: true
            }
            
        })


        const newRe= [...resultCode,...medicine];
        const cn = Object.assign(resultCode, medicine)
        const up = resultCode.map(obj => {
            if(obj.udProductCode === resultCode.udProductCode){
                return medicine;
            }
            return obj;
        })
        // console.log("up", newRe)
        const indexed = Object.fromEntries(resultCode.map(o => [o.udProductCode, o]))
        const combined = result.map(o => ({...o, ...indexed[o.udProductCode]}))
        res.send({ success: true, "message": "Show Successfully", resultCode, medicine,result});        
    } catch (error) {
        next(error)        
    }
}



exports.getDetailsByMedicine = async(req, res, next) => {
    try {
       
        const result = await prisma.rxApproveChild.findMany({
            where: {
                rxMedicineStatus:1,
                udProductCode: req.params.udProductCode || 0
            },
            include: {
                rxApproveParents: true
            },
            include: {
                rxApproveParents: {
                    include: {
                        presGenerateParent: {
                            select: {
                            empOldId: true,
                            empName:true
                            }
                        }
                    }
                }
            }

        })
        res.send({ success: true, "message": "Show Successfully", result});        
    } catch (error) {
        next(error)        
    }
}

exports.rxMedicinForHO = async(req, res, next) => {
    try {
        // console.log("rr", req.body)
        const{prescriptionId, totalMediQty, medicineInfo} = req.body
        const result = await prisma.rxMediReForHoParent.create({
           data: {
            prescriptionId:prescriptionId,
            totalMediQty: totalMediQty,
            orgId: req.user.orgId,
            rxMediReForHoChild: {create:medicineInfo}
           }
        })
      
        const allId = []; 
        medicineInfo.forEach(function(obj, index) {
        const sValue = Object.values(obj);
        allId.push(sValue[0])
        });

        console.log("allId", allId)

        const result2 = await prisma.rxApproveChild.updateMany({
            where: {
                id: { in: allId }    
            },
            data: {     
                rxMedicineStatus:2,
                orgId: req.user.orgId
            }
         })
         res.send({ success: true, "message": "Insert Successfully", result, result2})          
    } catch (error) {
        next(error);
    }
}

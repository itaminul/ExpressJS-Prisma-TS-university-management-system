const prisma = require('../../prisma/index')

exports.employeList = async(req, res, next) => {
    try {
        
        const result = await prisma.presGenerateParent.findMany({
            distinct: ['empOldId'],
            select: {
                empName: true,
                empOldId: true
            }
        })
        res.send({ success: true, "message": "Show Successfully", result })
    } catch (error) {
        next(error);
    }
}
// Get employee after medicine delivery
exports.getPatientsAfterMediDelivery = async (req, res, next) => {
    try {
        const result = await prisma.rxMediReForHoChild.findMany()
        res.send({ success: true, "message": "Show Successfully", result })
    } catch (error) {
        next(error);
    }
}

// Get paid
exports.getPatientsOfAmountPaid = async (req, res, next) => {
    try {
        const result = await prisma.rxMediReForHoChild.findMany({
            where: {
                prescriptionId: req.body.id,
                rxMediPaidStatus: 2
            }
        })
        res.send({ success: true, "message": "Show Successfully", result })
    } catch (error) {
        next(error);
    }
}

// Get due 
exports.getPatientsOfAmountDue = async (req, res, next) => {
    try {
        const result = await prisma.rxMediReForHoChild.findMany({
            where: {
                prescriptionId: req.body.id,
                rxMediPaidStatus: 1
            }
        })
        res.send({ success: true, "message": "Show Successfully", result })
    } catch (error) {
        next(error);
    }
}


exports.getDueInformation = async (req, res, next) => {
    try {
        const genePres = await prisma.presGenerateParent.findMany({
            select: {
                id: true,
                empName: true
            }
        })
        const presId = await prisma.rxMediReForHoChild.findMany({
            orderBy: { prescriptionId: 'asc' },
            distinct: ['prescriptionId'],
            where: {
                prescriptionId: genePres.id,
                rxMediPaidStatus: 1,
                rxMediReceiveStatus: 3
            },
            include: {
                presGenerateParent: {
                    select: {
                        empName: true
                    }
                }
            }
        })

        const presIdArray = [];
        presId.map((obj, ind) => {
            const presValue = Object.values(obj);
            presIdArray.push(presValue[6]);
        })
        const due = await prisma.rxMediReForHoChild.findMany({
            orderBy: { prescriptionId: 'asc' },
            where: {
                prescriptionId: { in: presIdArray },
                rxMediPaidStatus: 1
            },
            include: {
                presGenerateParent: true
            }
        })

        const onlyDue = await prisma.rxMediReForHoChild.findMany({
            where: {
                rxMediPaidStatus: 1,
                rxMediReceiveStatus: 3
            },
            include: {
                presGenerateParent: true
            }
        })

        const customArray = [];

        for (const val of onlyDue) {
            const cArray =
            {
                medicineName: val.medicineName,
                qty: val.totalMedicineQty,
                amount: val.amount,
                presGenerateParent: val.presGenerateParent.empName,
                prescriptionGenDate: val.presGenerateParent.prescriptionGenDate,
                medicineDeliveryDate: val.presGenerateParent.medicineDeliveryDate,
                prescriptionId: val.presGenerateParent.id,
                empOldId: val.presGenerateParent.empOldId,

            }

            const bb = await prisma.rxMediReForHoChild.findMany({
                where: {
                    prescriptionId: { in: [Number(val.presGenerateParent.id)] }
                }
            })

            customArray.push(cArray);

        }


        const uniqueIds = new Set();

        const unique = customArray.filter(element => {
            const isDuplicate = uniqueIds.has(element.empOldId);
            uniqueIds.add(element.empOldId);
            if (!isDuplicate) {
                return true;
            }
            return false;
        });
        // console.log("unique", unique);

        for (const dueListV of customArray) {
            const cdueList = [
                {
                    // presGenerateParent: dueListV.presGenerateParent,
                    medicineName: dueListV.medicineName
                }
            ]
            // console.log("medicine name", cdueList);
        }
        // var bird = customArray.findMany(bird => bird.empOldId === empOldId);

        // console.log("bird",bird);


        const dueList = customArray
        res.send({ success: true, "message": "Show Successfully", dueList })
    } catch (error) {
        next(error);
    }
}


exports.getDueByEmployeeWise = async (req, res, next) => {

    try {
        const presId = await prisma.presGenerateParent.findMany({
            where: {
                empOldId: (req.params.id)
            },
            select: {
                id: true
            }
        })

        const presIdCustome = []
        for (const item of presId) {
            presIdCustome.push(item.id)
        }



        const result = await prisma.rxMediReForHoChild.findMany({
            where: {
                prescriptionId: { in: presIdCustome },
                rxMediPaidStatus: 1,
                rxMediReceiveStatus: 3
            },
            include: {
                presGenerateParent: true
            }
        })
        res.send({ success: true, "message": "Show Successfully", result })
    } catch (error) {
        next(error);
    }

}

exports.getnewIormation = async (req, res, next) => {
    try {
        const presId = await prisma.rxMediReForHoChild.findMany({
            orderBy: { prescriptionId: 'asc' },
            distinct: ['prescriptionId'],
            where: {
                prescriptionId: req.body.id,
                rxMediPaidStatus: 1
            },
            include: {
                presGenerateParent: {
                    select: {
                        empName: true
                    }
                }
            }
        })

        const presIdArray = [];
        presId.map((obj, ind) => {
            const presValue = Object.values(obj);
            presIdArray.push(presValue[5]);
        })
        const due = await prisma.rxMediReForHoChild.findMany({
            orderBy: { prescriptionId: 'asc' },
            where: {
                prescriptionId: { in: presIdArray },
                rxMediPaidStatus: 1
            },
            include: {
                presGenerateParent: true
            }
        })

        const ca = [...presId, due]

        // const mPres = ca.forEach((element, index) => {
        //     presId[index] = element + index;
        // })
        // console.log('dd', presId)
        // const preIdMapA={};
        const preIdMap = presId.map((obj, objv) => {
            return [obj.prescriptionId, obj.presGenerateParent.empName]
        })

        const dueMap = due.map((objd, objdv) => {
            return [objd.prescriptionId, objd.medicineName, objd.totalMedicineQty, objd.amount, objd.presGenerateParent.empName];
        })

        const amurge = preIdMap.concat(dueMap);
        const geNew = due.find((obj) => {
            return obj.id === 173
        })

        const json = JSON.stringify(presId)
        const { ...newName } = presId
        // newName.push(presId.medicineName)
        const aa = [];
        for (let i in presId.presGenerateParent) {
            const vv = x += "<h2>" + presId.presGenerateParent[i].empName + "</h2>"
            aa.push(vv)
        }

        res.send({ success: true, "message": "Show Successfully", presId })
    } catch (error) {
        next(error);
    }
}
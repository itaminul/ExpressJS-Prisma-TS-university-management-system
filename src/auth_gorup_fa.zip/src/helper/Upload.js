//https://codeforgeek.com/file-uploads-using-node-js/
const path = require('path')
const multer = require('multer')
 
var storage = multer.diskStorage({
	destination: (req,file,cb)=> {
		cb(null,'./src/upload');
	},
	filename: (req,file,cb)=> {
        console.log("file", file)
		cb(null, Date.now() + file.originalname);
	}
});
var upload = multer({
	storage: storage,
	fileFilter: (req,file,cb)=> {
		// console.log('In File Filter');
			let ext = path.extname(file.originalname);
			if(ext == '.jpg' || ext == '.png' || ext == '.gif' || ext == '.jpeg') {
				console.log('Extension Check');
				cb(null,true);
			}
			else {
				cb('Only Images Are Allow', false);
			}
	}
}).single('uploadImage');
 
module.exports = upload



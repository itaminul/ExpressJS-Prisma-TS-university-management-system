const passport = require('passport')
const localStrategy = require('passport-local').Strategy

const bcrypt = require('bcrypt')

function initialize(passport) {
    console.log('passport show', passport)

    const authenticateUser = async(userName, password, done) => {
        const user = getUserByName(userName)

        if(user == null) {
            return done(null, false, { message: 'Not user with that email'})
        }

        try {
            if (await bcrypt.compare(password, user.password)) {
                return done(null, user)
            }else{
                return done(null, false, { message: "Password incorrect"})
            }
        } catch (error) {
            return done(error)
            
        }

    }

    passport.use(new localStrategy({}, function(req, userName, password, done) {}),
    
    authenticateUser)

    passport.serializeUser(( user, done) => done(null, user.id))
    passport.deserializeUser(( id, done) => {
        done(null, getUserById(id))
     })

}

module.exports = initialize
const LocalStrategy = require('passport-local').Strategy
const passport = require('passport')
const prisma = require('./prisma/connection')

const initializingPassport = () => {
    passport.use( new LocalStrategy(async(userName, password,done) => {

        try {
            const user = await prisma.user.findUnique({
                where: {
                    userName: userName
                }
            })
            if(!user) return done(null, false)
    
            if(user.password !== password) return done(null, false)
            return done(null, user)
        } catch (error) {
            return done(error, false)
        }

    }))
}

passport.serializeUser((user, done) => {
    done(null, user.id)
})

passport.deserializeUser(async (id, done) => {
    try {
        const user = await prisma.user.findUnique({
            where: {
                id: id
            }
        })
        done(null, user)
    } catch (error) {
        done(error, false)
        
    }
})

module.exports = initializingPassport
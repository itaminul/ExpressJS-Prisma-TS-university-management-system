const LocalStrategy = require('passport-local').Strategy
  
const bcrype = require('bcrypt')

function initialize(passport, getUserByUserName) {
    const authenticateUser = (userName, password, done) => {
        const user = getUserByUserName(userName)
        if(user == null) {
            return done(null, false, { message: 'no user found'})
        }

        try {
            if( bcrype.compare(password, user.password)) {
                return done(null, user)

            }else{
                return done(null, false, { message: 'password incorrect'})
            }
        } catch (error) {
            return done(e)
            
        }

    }

    passport.use(new LocalStrategy( {userNameFiled: 'userName'}),
    authenticateUser)
    passport.serializeUser((user, done) => {})
    passport.deserializeUser((id, done) => {})

}

module.exports =initialize
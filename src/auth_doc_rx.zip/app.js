const express = require('express');
const cors = require('cors')
const http = require('http')
const bodyParser = require("body-parser");
const cookieParser = require('cookie-parser')
const { ErrorHandler } = require('./src/middlewares/ErrorHandler');
const passport = require('passport')
const prisma = require('./prisma/connection')

const initializingPassport =  require('./passportConfing.js')


//important passport and session login
//https://www.youtube.com/watch?v=-RCnNyD0L-s



/*
initializePassport => {(
  passport,
  uaserName => prisma.user.findUnique (user => user.uaserName === uaserName)
) }
const users = []
*/
const app =  express();



app.use(cors())
app.use(express.json())
app.use(cookieParser())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }));

require('dotenv').config();


const port = process.env.PORT;
const databae = process.env.DATABASE_URL;
const hostname = process.env.HOSTNAME;


/*
//https://www.youtube.com/watch?v=o256D3tztV8
//https://www.youtube.com/watch?v=-RCnNyD0L-s

const session = require('express-session')

initializingPassport(passport)


app.use(passport.initialize())
app.use(passport.session())


app.use(session(
  session({
    resave: false,
    saveUninitialized: false,
    secret: process.env.SESSION_SECRET,
    cookie: {
      secure: true,
      maxAge: 3000000 *60
    },
  })
))


*/


const router = require('./src/routes/indexRoutes');
 app.use('/api', router)

 app.use(ErrorHandler)

app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});


/*
const express = require('express');
const prisma = require('./prisma/connection')
const session = require('express-session')
// Importing file-store module
const filestore = require("session-file-store")(session)
const passport = require('passport')
const passportLocal = require('passport-local')
const cors = require('cors')
const http = require('http')
const bodyParser = require("body-parser");
const cookieParser = require('cookie-parser')
const { ErrorHandler } = require('./src/middlewares/ErrorHandler');
const app =  express();

passport.initialize();
app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser((user, done) => done(null, prisma.user.data._id));

passport.deserializeUser(async (id, done) => {
  let [err, user] = await to(prisma.user.findUnique(id).exec());
  if (err) {
    console.error(err);
  }
  user = new user(user);
  return done(err, user);
});


// passport.use(new LocalStrategy(User.authenticate()));

app.use(session({
  name: "sessionId",
  secret:"Any normal Word",       //decode or encode session
  resave: false,          
  saveUninitialized:false,
  resave: false,
  store: new filestore(),
  cookie:{
      maxAge: 365 * 24 * 60 * 60 * 1000
  }    
}));


app.use(cors())
app.use(express.json())
app.use(cookieParser())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }));

require('dotenv').config();


const port = process.env.PORT;
const databae = process.env.DATABASE_URL;
const hostname = process.env.HOSTNAME;

// create the homepage route at '/'
app.get('/pp', (req, res) => {
  console.log('Inside the homepage callback function')
  console.log("session id",req.sessionID)
  res.send(`You hit home page!\n`)
})

const router = require('./src/routes/indexRoutes');

 app.use('/api', router)

 app.use(ErrorHandler)

app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});


*/
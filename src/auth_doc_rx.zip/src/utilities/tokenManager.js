const jwt = require('jsonwebtoken')

const generateToken = async(user) => {
    try {
        const payload = { _id: user._id, userRoleId: user.userRoleId}
        const accessToken = jwt.sign(
            payload,
            process.env.SECRET_KEY,
            {expiresIn: "14m"}
        )

        const refreshToken = jwt.sign(
            payload,
            process.env.REFRESH_TOKEN,
            {expiresIn: "30d"}
        )

        const userToken = await UserToken.findOne({ userId: user._id})
        if(userToken) await userToken.remove();
        await new UserToken({ userId: user._id, token: refreshToken}).save();
        return Promise.resolve({ accessToken, refreshToken})
    } catch (error) {
        return Promise.reject(error)
        
    }
}
/*const generateToken = (uid) => {
    console.log(uid)
    console.log('uid')
    const expiresIn = 60 * 15
    try {
       const token = jwt.sign({uid}, process.env.JWT_SECRET, { expiresIn })
       return {token, expiresIn}
    } catch (error) {
        console.log(error)
        
    }
}
*/
module.exports = generateToken
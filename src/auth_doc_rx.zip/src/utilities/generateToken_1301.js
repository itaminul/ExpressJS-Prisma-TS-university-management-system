const prisma = require('../../prisma/connection')
const jwt = require('jsonwebtoken')

const generateTokens = async(user) => {
    try {

        const payload = { id: user.id}
        // console.log("payload", payload)
        const accessToken = jwt.sign(
            payload,
            process.env.ACCESS_TOKEN_PRIVATE_KEY,
            { expiresIn: "14m"},
            "jwtsecretplschange"
        );

        return accessToken;
        console.log("accessToken", accessToken)

        const validateToken = (req, res, next) => {
            const accessToken = req.cookies["access-token"]
            if(!accessToken)
            res.send({ success: true, "message": "invalied"})

            try {
                const validToken = jwt.verify(accessToken, "jwtsecretplschange")
                if(validToken) {
                    req.authenticated = true
                    return next()
                }
            } catch (error) {
                res.send({ success: true, "message": "error"})
                
            }


        }

        const refreshToken = jwt.sign(
            payload,
            process.env.REFRESH_TOKEN_PRIVATE_KEY,
            {expiresIn: "30d"}

        )

        console.log("refreshToken", refreshToken)
        // result.send("payload", payload)

        // const userToken = await prisma.userToken.findFirst({ userId: user.id})
        // console.log("userToken", userToken)
      
      /*  if(userToken) await prisma.userToken.delete({
            userId: user.id
        })

        // let {categoryName, description, slNo} = req.body;
        let result = await prisma.userToken.create({
            data: {
                userId: user.id, token: refreshToken
            }
        })
        */



        // await new userToken({ userId: user._id, token: refreshToken})
        // if(userToken) await userToken.remove()


    } catch (error) {
        
    }
}

module.exports = generateTokens

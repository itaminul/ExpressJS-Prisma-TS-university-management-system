const prisma = require('../../prisma/connection')
const jwt = require('jsonwebtoken')

const verifyRefreshToken = (refreshToken) => {
    const privateKey = process.env.REFRESH_TOKEN_PRIVATE_KEY;

    return new Promise((resolve, reject) => {
        prisma.userToken.findFirst({ token: refreshToken}, (error, doc) => {
            if(!doc)
            return reject({ error: true, message: "Invalied refresh token"})
            
            jwt.verify(refreshToken, privateKey, (error, tokenDetails) => {
                if(error) 
                return reject( {error: true, message: "Invalid refresh token"});
                resolve({
                    tokenDetails,
                    error: false,
                    message: "valid refresh token"
                })
            })
        })
    })
}

module.exports = verifyRefreshToken;
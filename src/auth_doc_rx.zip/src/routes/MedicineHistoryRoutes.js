const express = require('express')
const router = express.Router()
const {create, getAll, update} = require('../controller/MedicineHistoryController')
router.route('/').post(create)
router.route('/:id').patch(update)
router.route('/').get(getAll)
module.exports= router
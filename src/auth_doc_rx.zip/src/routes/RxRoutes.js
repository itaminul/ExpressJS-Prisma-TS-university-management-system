const express = require('express')
const router = express.Router()
const {create, getAll, update, getRxInformationByPatients, statusChange} = require('../controller/RxController')
router.route('/').post(create)
router.route('/:id').patch(update)
router.route('/').get(getAll)
router.route('/getRxInformationByPatients/:id').get(getRxInformationByPatients)
router.route('/statusChange/:id').patch(statusChange)



module.exports= router
const express = require('express')
const auth = require('../middlewares/isLoggedIn')
const { getAll, create, update, deleteCategory } = require('../controller/CategoryController')

const router = express.Router()
router.route('/').get(getAll)
router.route('/').post(create)
router.route('/:id').patch(update)
router.route('/:id').delete(deleteCategory)
module.exports=router
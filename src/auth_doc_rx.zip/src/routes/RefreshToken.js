const prisma = require('../../prisma/connection')
const jwt = require('jsonwebtoken')

const verifyRefreshToken = require('../utilities/VerifyRefreshToken')


const express = require('express')
const { getAll, create, update, deleteAdvice  } = require('../controller/AdviceController')
const router = express.Router()
router.route('/').get(getAll)
router.route('/').post(create)
router.route('/:id').patch(update)
router.route('/:id').delete(deleteAdvice)
module.exports=router
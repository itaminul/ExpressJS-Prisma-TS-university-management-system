const express = require('express')
const { getAll, create, update, deleteInvestigations,  } = require('../controller/InvestigationsController')
const router = express.Router()
router.route('/').get(getAll)
router.route('/').post(create)
router.route('/:id').patch(update)
router.route('/:id').delete(deleteInvestigations)
module.exports=router
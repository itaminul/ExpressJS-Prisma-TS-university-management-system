const express = require('express')
const { getAll, create, update, deleteChiefComplaints  } = require('../controller/ChiefComplaintsController')
const router = express.Router()
router.route('/').get(getAll)
router.route('/').post(create)
router.route('/:id').patch(update)
router.route('/:id').delete(deleteChiefComplaints)
module.exports=router
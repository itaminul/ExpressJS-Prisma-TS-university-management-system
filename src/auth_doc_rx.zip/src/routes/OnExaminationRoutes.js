const express = require('express')
const { getAll, create, update, deleteOnExamination  } = require('../controller/OnExaminationController')
const router = express.Router()
router.route('/').get(getAll)
router.route('/').post(create)
router.route('/:id').patch(update)
router.route('/:id').delete(deleteOnExamination)
module.exports=router
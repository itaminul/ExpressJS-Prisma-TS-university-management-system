const express = require('express');
const { create, getAll, update } = require('../controller/PrescriptionFooterController');
const router = express.Router();
router.route('/').get(getAll)
router.route('/').post(create)
router.route('/:id').patch(update)
module.exports= router
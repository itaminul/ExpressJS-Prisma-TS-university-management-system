const express = require('express')
const bcrype = require('bcrypt')
const joi = require('joi')
const passwordComplexity = require('joi-password-complexity')
//https://www.youtube.com/watch?v=KqcEVUI7-s0

const { getAll, signUp, userLogin, verfyRefreshToken, userLogout } = require('../controller/AuthController')
const router = express.Router();
router.route('/').get(getAll)
router.route('/').post(signUp)
router.route('/login').post(userLogin)
router.route('/logout').post(userLogout)
router.route('/refresh').post(verfyRefreshToken)

module.exports = router
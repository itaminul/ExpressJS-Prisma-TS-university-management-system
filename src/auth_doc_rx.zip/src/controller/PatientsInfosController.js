const prisma = require('../../prisma/connection')
const ISODate = require('isodate');
exports.getAll = async(req, res, next) => {
    try {
        let result = await prisma.patientsInfos.findMany({
            include: {
                patientMedicineHistory: true
            }
        })
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.getAlreadyAppointedPatients = async(req, res, next) => {
    try {
        let result = await prisma.rxMedicineParent.findMany({
            //include multiple relation table
            include: {
                //get patients information
                patientsInfos: true,    
                //relation rx with medicine generic category and medicine manfacturer
                rxMedicine: {
                    include: {
                        medicine: {
                            include: {
                                medicineGeneric: true,
                                category: true,
                                medicineManufacturer:  true
                            }
                        }

                    }
                },

                rxExaminations: {
                    include: {
                        onExamination: {
                            select: {
                                name: true
                            }
                        }
                    }

            },

            rxComplaints: {
                include: {
                    chiefComplaints: true
                }
            },

            rxDiagnosis: {
                include: {
                    diagnosis: true
                }
            },

            rxInvestigation: {
                include: {
                    investigations: true
                }
            },

            rxAdvice: {
                include: {
                    advice: true
                }
            }
        }
        })
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}

/*
exports.getAlreadyAppointedPatients = async(req, res, next) => {
    try {
        let result = await prisma.rxMedicineParent.findMany({
            where: { rxMedicineParent: { some: {} } },
            include: {
                patientMedicineHistory: true,
                patientsInfos: true               
            }
        })
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}*/

exports.getUpCommeingPatientsWithoutPres = async(req, res, next) => {
    try {
        let result = await prisma.patientsInfos.findMany({
            where: {
                //  rxMedicineParent: { none: {} },
                 appointmentDate: {
                    gt: new Date()
                 } 
                },
            include: {
                patientMedicineHistory: true,
               
            }
            // include: {
            //     patientAppoinInfo: {
            //         where: {
            //             NOT: {
            //                 patientAppintSatus:2
            //             }
            //         },
            //     }
            // }
        })
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.getAllPatientsByCurrentDate = async(req, res, next) => {
    try {
      
        let result = await prisma.patientsInfos.findMany({
            // where: {
            //     appointmentDate:  { 
            //         equals: new Date().toLocaleDateString()
            //     },
            //     // rxMedicineParent: { none: {} }
            // },
            include: {
                patientMedicineHistory: true
            },
            include: {
                patientAppoinInfo: {
                    where: {
                        appointmentDate: {
                            equals:new Date().toLocaleDateString(),
                        },
                        patientAppintSatus:1
                    },
                }
            }

        })

        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.create = async(req, res, next) => {
    try {

        const pId = await prisma.patientsInfos.aggregate({
            _max: {
                patientId: true
            }
        })
        const maxPId = pId._max;
        const getMaxPatientId = maxPId.patientId+1;    

        let {
            name,
            age,
            phone,
            appointmentDate,
            gender,
            email,
            bloodGroup,
            height,
            weight,
            bmr,
            activeLebel,
            tdee,
            bsa,
            bmi,
            nationalId,
            address,
            refereedBy,
            refereedTo,
            registrationNo,
            disease,
            presentComplaints,
            systemicExamination,
            patientOutcome,
            physicaExamination,
            comorbidity,            
            medicinelists,
            visitedStatus,
            investigationsHistory,
            patientAppoinInfos
        } = req.body;

        let result = await prisma.patientsInfos.create({
            data: {
                name,
                age,
                patientId: getMaxPatientId,
                phone,
                appointmentDate: new Date(appointmentDate),
                gender,
                email,
                bloodGroup,
                height,
                weight,
                bmr,
                activeLebel,
                tdee,
                bsa,
                bmi,
                nationalId,
                address,
                refereedBy,
                refereedTo,
                registrationNo,
                disease,
                presentComplaints,
                systemicExamination,
                patientOutcome,
                physicaExamination,
                comorbidity,
                visitedStatus,
                patientMedicineHistory:{ create: medicinelists},
                    patientAppoinInfo: { 
                        create: {
                                appointmentDate: new Date(appointmentDate).toLocaleDateString()
                            
                        }
                    },
                

                investigationsHistory
                // patientInvestigationsHistory:{ create: investigationsList}
            }
        })
        res.json({ success: true, "message": "Save successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.update = async(req, res, next) => {
    try {
        let {
            name,
            age,
            phone,
            appointmentDate,
            gender,
            email,
            bloodGroup,
            height,
            weight,
            bmr,
            activeLebel,
            tdee,
            bsa,
            bmi,
            nationalId,
            address,
            refereedBy,
            refereedTo,
            registrationNo,
            disease,
            presentComplaints,
            systemicExamination,
            patientOutcome,
            physicaExamination,
            comorbidity,
            visitedStatus,
            investigationsHistory
        } = req.body;

        let result = await prisma.patientsInfos.update({
            where: {
                id: req.params.id
            },
            data: {
                name,
                age,
                phone,
                appointmentDate: new Date(appointmentDate),
                gender,
                email,
                bloodGroup,
                height,
                weight,
                bmr,
                activeLebel,
                tdee,
                bsa,
                bmi,
                nationalId,
                address,
                refereedBy,
                refereedTo,
                registrationNo,
                disease,
                presentComplaints,
                systemicExamination,
                patientOutcome,
                physicaExamination,
                comorbidity,
                visitedStatus,
                investigationsHistory
            }
        })
        res.json({ success: true, "message": "Update successfully", result})    

    } catch (error) {
        next(error)        
    }
}

exports.editWithAppointment = async(req, res, next) => {
    try {      

        const { appointmentDate }= req.body;
        const appDate = appointmentDate;
        const result = await prisma.patientAppoinInfo.create({
            data: {
                appointmentDate: new Date(appDate).toLocaleDateString(),
                patientInfoId: req.params.id
            }
        })
        res.json({ success: true, "message": "Update successfully", result})  
    } catch (error) {
        next(error)        
    }
}

exports.deletePatients = async(req, res, next) => {
    try {    
        let result = await prisma.patientsInfos.delete({
            where: {
                id: req.params.id
            }
        })
        res.json({ success: true, "message": "Delete successfully", result})        
    } catch (error) {
        next(error)        
    }
}
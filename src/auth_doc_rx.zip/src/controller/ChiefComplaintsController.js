const prisma = require('../../prisma/connection')

exports.getAll = async(req, res, next) => {
    try {
        let result = await prisma.chiefComplaints.findMany()
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.create = async(req, res, next) => {
    try {
        let {name, description, slNo} = req.body;
        let result = await prisma.chiefComplaints.create({
            data: {
                name, description, slNo,activeStatus:1
            }
        })
        res.json({ success: true, "message": "Save successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.update = async(req, res, next) => {
    try {
        let {name, description, slNo,activeStatus} = req.body;
        let result = await prisma.chiefComplaints.update({
            where: {
                id: req.params.id
            },
            data: {
                name, description, slNo,activeStatus
            }
        })
        res.json({ success: true, "message": "Update successfully", result})    

    } catch (error) {
        next(error)        
    }
}


exports.deleteChiefComplaints = async(req, res, next) => {
    try {    
        let result = await prisma.chiefComplaints.delete({
            where: {
                id: req.params.id
            }
        })
        res.json({ success: true, "message": "Delete successfully", result})        
    } catch (error) {
        next(error)        
    }
}
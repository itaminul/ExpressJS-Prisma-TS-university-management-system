const prisma = require('../../prisma/connection')

exports.getAll = async(req, res, next) => {
    try {
        const result = await prisma.prescriptions.findMany()
        res.send({ success: "true", "message": "Show successfully", result})
    } catch (error) {
        next(error)        
    }
}

exports.create = async(req, res, next) => {
    try {
        const {
        patientId,
        patientRandomId,
        name,
        chiefComplaints,
        onExaminations,
        diagnosis,
        investigations,
        rx
         } = req.body

    const result = await prisma.prescriptions.create({
        data: {
        patientId,
        patientRandomId,
        name,
        chiefComplaints,
        onExaminations,
        diagnosis,
        investigations,
        rx
        },        
    })
    res.send({success: true, "message": "Create successfully", result})
    } catch (error) {
        next(error)
    }
}

exports.update = async(req, res, next) => {
    try {
        const {
            patientId,
            patientRandomId,
            name,
            chiefComplaints,
            onExaminations,
            diagnosis,
            investigations,
            rx
             } = req.body
             

    /*         
        const deleteMedHis = await prisma.patientMedicineHistory.delete({
            where: {
                id: req.params.id
            }
        })  
        const deleteMedInves = await prisma.patientInvestigationsHistory.delete({
            where: {
                id: req.params.id
            }
        })     
    */
        const result = await prisma.prescriptions.update({
            where: {
              id: req.params.id  
            },
            data: {
            patientId,
            patientRandomId,
            name,
            chiefComplaints,
            onExaminations,
            diagnosis,
            investigations,
            rx   
            },        
        })
        
        res.send({success: true, "message": "Show successfully", result})
    } catch (error) {
        next(error)
        
    }
}
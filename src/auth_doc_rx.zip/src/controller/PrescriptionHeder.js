const prisma = require('../../prisma/connection')

exports.getAll = async(req, res, next) => {
    try {
        const result = await prisma.prescriptionHeader.findMany({
            where: {
                activeStatus: 1
            }
        })
        res.send({ success: true, "message": "Show successfully", result})
        
    } catch (error) {
        next(error)        
    }
}

exports.create = async(req, res, next) => {
    try {

        const { doctorName, doctorMajorDegree,specialist,doctorMinorDegree, training, hospitalName, activeStatus } = req.body;
        const result = await prisma.prescriptionHeader.create({
            data: {
                doctorName, doctorMajorDegree,specialist,doctorMinorDegree, training, hospitalName,activeStatus

            }
        })
        res.send({ success: true, "message": "Save successfully", result})
        
    } catch (error) {
        next(error)        
    }
}
exports.update = async(req, res, next) => {
    try {
        const {   doctorName, doctorMajorDegree,specialist,doctorMinorDegree, training, hospitalName,activeStatus } = req.body;
        const result = await prisma.prescriptionHeader.update({
            where: {
                id: req.params.id
            },
            data: {
                doctorName, doctorMajorDegree,specialist,doctorMinorDegree, training, hospitalName,activeStatus

            }
        })
        res.send({ success: true, "message": "Update successfully", result})
    } catch (error) {
        next(error)        
    }
}
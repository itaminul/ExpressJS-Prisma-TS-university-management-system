const prisma = require('../../prisma/connection')

exports.getAll = async(req, res, next) => {
    try {
        const result = await prisma.prescriptionFooter.findMany({
            where: {
                activeStatus: 1
            }
        })
        res.send({ success: true, "message": "Show successfully", result})
        
    } catch (error) {
        next(error)        
    }
}

exports.create = async(req, res, next) => {
    try {

        const {  hospitalName, address, helpline,email, serialPhoneNumber, activeStatus } = req.body;
        const result = await prisma.prescriptionFooter.create({
            data: {
                hospitalName, address, helpline,email, serialPhoneNumber, activeStatus

            }
        })
        res.send({ success: true, "message": "Save successfully", result})
        
    } catch (error) {
        next(error)        
    }
}


exports.update = async(req, res, next) => {
    try {
        const { hospitalName, address, helpline,email, serialPhoneNumber, activeStatus } = req.body;
        const result = await prisma.prescriptionFooter.update({
            where: {
                id: req.params.id
            },
            data: {
                hospitalName, address, helpline,email, serialPhoneNumber, activeStatus

            }
        })
        res.send({ success: true, "message": "Update successfully", result})
    } catch (error) {
        next(error)        
    }
}
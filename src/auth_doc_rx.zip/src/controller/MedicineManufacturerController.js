const prisma = require('../../prisma/connection')

exports.getAll = async(req, res, next) => {
    try {
        let result = await prisma.medicineManufacturer.findMany()
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.create = async(req, res, next) => {
    try {

        let { manufacturerName, slNo, description, activeStatus } = req.body;
        let result = await prisma.medicineManufacturer.create({
            data: {
                manufacturerName, slNo, description, activeStatus 
            }
        })
        res.json({ success: true, "message": "Save successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.update = async(req, res, next) => {
    try {
        let {
            manufacturerName, slNo, description, activeStatus 
        } = req.body;


        let result = await prisma.medicineManufacturer.update({
            where: {
                id: req.params.id
            },
            data: {
                manufacturerName, slNo, description, activeStatus 
            }
        })
        res.json({ success: true, "message": "Update successfully", result})    

    } catch (error) {
        next(error)        
    }
}

exports.deletePatients = async(req, res, next) => {
    try {    
        let result = await prisma.medicineManufacturer.delete({
            where: {
                id: req.params.id
            }
        })
        res.json({ success: true, "message": "Delete successfully", result})        
    } catch (error) {
        next(error)        
    }
}
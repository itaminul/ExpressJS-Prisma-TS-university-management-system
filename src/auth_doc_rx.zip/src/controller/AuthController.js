const prisma = require('../../prisma/connection')
const jwt = require('jsonwebtoken')
const cookiToken = require('../utilities/cookieToken')
const generateTokens = require('../utilities/generateTokens')
const verifyRefreshToken = require('../utilities/VerifyRefreshToken')
const bcrypt = require('bcrypt')
const cookieParser = require('cookie-parser')
const { signUpBodyValidation, logInBodyValidation } = require('../utilities/validationSchema')
//https://www.youtube.com/watch?v=KqcEVUI7-s0
//https://www.youtube.com/watch?v=nI8PYZNFtac
//https://www.youtube.com/watch?v=s-4k5TcGKHg
//important

//https://dev.to/cyberwolves/jwt-authentication-with-access-tokens-refresh-tokens-in-node-js-5aa9
//https://github.com/bezkoder/node-js-express-login-example/blob/master/app/middleware/authJwt.js

//very very important
//https://mfikri.com/en/blog/react-express-mysql-authentication
//https://dev.to/cyberwolves/jwt-authentication-with-access-tokens-refresh-tokens-in-node-js-5aa9
//https://snyk.io/advisor/npm-package/jsonwebtoken/functions/jsonwebtoken.TokenExpiredError
//https://javascript.plainenglish.io/expressjs-api-with-secure-jwt-access-and-refresh-token-64c5478be2c0//

//===========

//FuturaBT,sans-serif
exports.getAll = async(req, res, next) => {
    try {
        let result = await prisma.user.findMany()
        res.json({ success: true, "message": "Data show successfully", result})
    } catch (error) {
        next(error)
    }    
}

/*
exports.signUp = async(req, res, next) => {
    try {
        let {name, userName, password, email, phone} = req.body
        let result = await prisma.user.create({
           data: {
            name, userName, password, email, phone
           }
        })
        cookiToken(result, res)
        // res.json({ success: true, "message": "Save successfully", result})
    } catch (error) {
        next(error)        
    }
}
*/


exports.signUp = async(req, res, next) => {
    try {

        // const { error } = logInBodyValidation(req.body)
        //get all data from body
        let {name, userName, password, email,roles, orgId, phone} = req.body
        // res.send(req.body)
        //get user name using wehre userName
        const user = await prisma.user.findFirst({ 
            where: {
                userName: userName
            }
        })

        //check if user exist

        if(user) {
            res.send({ success: true, "message": "User Already Exist"})
        }

        //incrypt the passwords
        const salt = await bcrypt.genSalt(Number(process.env.SALT))

        const hashPassword = await bcrypt.hash(password, salt)

        // save the user information
        let result = await prisma.user.create({
           data: {
            name,
            userName,
            password:hashPassword,
            email,
            phone,
            roles, 
            orgId 
           }
        })

        res.send({ success: true, "message": "User Create Successfully", result})
        // cookiToken(result, res)
        // res.json({ success: true, "message": "Save successfully", result})
    } catch (error) {
        next(error)        
    }
}

exports.userLogin = async(req, res, next) => {
    try {
        let { userName, password } = req.body;

            // user name required validation
            if(!userName) {
                res.json({ success: false, "message": "Please provide username"}); 
            }
            //password required validation
            if(!password) {
                res.json({ success: false, "message": "Please provide password"}); 
            }

            const  userInfo = await prisma.user.findFirst({
                where: {
                    userName: userName
                }
            })
           
            //check user

        if(!userInfo) {
            res.send({ error: true, "message": "Invalied User Name"})
        }
        //verify password

        const verifiedPassword = await bcrypt.compare(
            req.body.password,
            userInfo.password
        )

        if(!verifiedPassword) {
            res.send({ error: true, "message": "Invalied User Name"})

        }
        
        
        const {accessToken, refreshToken} =await generateTokens(userInfo)

            res.send({error: false, "message": "Login Successfully", accessToken, userInfo})
    } catch (error) {
        next(error)
        
    }



}

exports.userLogout = async(req, res, next) => {
    try {
        // console.log(req.cookies.refreshToken)
        // res.sne(req.body)
        
    } catch (error) {
        
    }
}

exports.verfyRefreshToken =  async(refreshToken,  next) => {
    console.log('dddd')
    const payload = await verifyRefreshToken(refreshToken)
    console.log(payload)


}

/*
exports.userLogin = async(req, res, next) => {
    try {

        //get all data 
        let { userName, password } = req.body;

        // user name required validation
        if(!userName) {
            res.json({ success: false, "message": "Please provide username"}); 
        }
        //password required validation
        if(!password) {
            res.json({ success: false, "message": "Please provide password"}); 
        }

        //find user in DB
        const  user = await prisma.user.findFirst({
            where: {
                userName: userName
            }
        })

        //check if user exist
        if(!user) 
        res.json({ error: true, "message": "Invalid email or password"});   


        const dbPassword = user.password;
        bcrypt.compare(password, dbPassword).then((match) => {
            if(!match) {
                res.send({ success: true, "message": "Wrong username and password"})
            }else{
                res.send({ success: true, "message": "loged in "})
            }
        })  

        const  accessToken = await generateTokens(user)
        console.log("accessToken sss", accessToken)
        res.cookie("access-token", accessToken, {
            maxAge: 60*60*24*30*1000
        })



        // send a token
     
             
    } catch (error) {
        next(error)
        
    }
    
}
*/

/*
exports.userLogin = async(req, res, next) => {
    try {

        //get all data 
        let { userName, password } = req.body;

        // user name required validation
        if(!userName) {
            res.json({ success: false, "message": "Please provide username"}); 
        }
        //password required validation
        if(!password) {
            res.json({ success: false, "message": "Please provide password"}); 
        }

        //find user in DB
        const  user = await prisma.user.findFirst({
            where: {
                userName: userName
            }
        })

        //check if user exist
        if(!user) 
        res.json({ error: true, "message": "Invalid email or password"});   

        //match the password
        if(user && (await bcrypt.compare(password, user.password))){
            const token = jwt.sign(
                {id: user.id},
                process.env.ACCESS_TOKEN_PRIVATE_KEY,
                { expiresIn: "14m"}

            )

            user.token = token
            user.password = undefined
            //send token in user cookie

            //cookie secton

            const options = {
                expires: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
                httpOnly: true
            
            }
            res.send({ success: true, "message": "Show cookies". cookie("token", token, options)})
            // res.status(200).cookie("token", token, options)


        }



        // send a token


        res.send({ success: true})
             
    } catch (error) {
        next(error)
        
    }
    
}*/



/*exports.userLogin = async(req, res, next) => {
    try {

        //get all data 
        let { userName, password } = req.body;

        if(!userName) {
            res.json({ success: false, "message": "Please provide username"}); 
        }
        if(!password) {
            res.json({ success: false, "message": "Please provide password"}); 
        }

        //find user in DB

        let user = await prisma.user.findFirst({
            where: {
                userName: userName
            }
        })


        if(!user) 
        res.json({ error: true, "message": "Invalid email or password"});   

        //match the password


        // send a token


        

        const verifiedPassword = await bcrypt.compare(
            req.body.password,
            user.password
        )   

        if(!verifiedPassword) 
        res.json({ error: true, "message": "Invalid email or password"});   

         const { accessToken, refreshToken } = await generateTokens(user)

         res.send({ error: false, "message": "success", accessToken, refreshToken})

        
        if(user) { 
            res.json({ success: true, "message": "Login Success"});   

        }

        if(user) {
            const token = jwt.sign(
                {
                  name: user.name,
                  email: user.email
                },
                'secret123'
            )
            res.json({ success: true, "message": "Login Success", token: token});   
        }else{
            console.log("user check",user)
            res.json({ success: false, "message": "Your username and password incorrect Login Faild"}); 
        }
             
    } catch (error) {
        next(error)
        
    }
    
}*/


exports.logOut = async(req, res, next) => {
    try {
        res.clearCookie('token')
        res.json({ success: true, "message": 'Successfullly Logout'})
        
    } catch (error) {
        next(error)
        
    }
}
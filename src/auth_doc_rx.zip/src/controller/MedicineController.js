const { medicine } = require('../../prisma/connection')
const prisma = require('../../prisma/connection')

exports.getAll = async(req, res, next) => {
    try {
        let result = await prisma.medicine.findMany({             
             include: {
                medicineGeneric: {
                    select: {
                        id: true,
                        genericName: true,
                        description: true
                    }
                },
                medicineManufacturer: {
                    select: {
                        id: true,
                        manufacturerName: true,
                        description: true
                    }
                },
                category: {
                    select: {
                        id: true,
                        categoryName: true,
                        description: true,
                        shortName: true
                    }
                }
            }
        })
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}
//2348937
//2348949
//2348914
exports.create = async(req, res, next) => {
    try {
        let {medicineName, medicineGenericeId, categoryId, strength, manufacturerId, description, slNo} = req.body;
        let result = await prisma.medicine.create({
            data: {
                medicineName, medicineGenericeId, categoryId, strength, manufacturerId, description, slNo,activeStatus : 1
            }
        })
        res.json({ success: true, "message": "Save successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.update = async(req, res, next) => {
    try {
        let {medicineName, medicineGenericeId, categoryId, strength, manufacturerId, description, slNo, activeStatus} = req.body;
        let result = await prisma.medicine.update({
            where: {
                id: req.params.id
            },
            data: {
                medicineName, medicineGenericeId, categoryId, strength, manufacturerId, description, slNo,activeStatus
            }
        })
        res.json({ success: true, "message": "Update successfully", result})    

    } catch (error) {
        next(error)        
    }
}


exports.deleteDiagnosis = async(req, res, next) => {
    try {    
        let result = await prisma.medicine.delete({
            where: {
                id: req.params.id
            }
        })
        res.json({ success: true, "message": "Delete successfully", result})        
    } catch (error) {
        next(error)        
    }
}
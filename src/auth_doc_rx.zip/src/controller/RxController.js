const { RxExaminations } = require('../../prisma/connection')
const prisma = require('../../prisma/connection')


exports.getAll = async(req, res, next) => {
    try {
        
        let result = await prisma.rxMedicineParent.findMany({
            include: {
                rxExaminations: {
                    include: {
                        onExamination: {
                            select: {
                                name: true
                            }
                        }
                    }

                },
                rxComplaints: {
                    include: {
                        chiefComplaints: {
                            select: {
                                name: true
                            }
                        }
                    }
                },
                rxDiagnosis: {
                    include: {
                        diagnosis: {
                            select: {
                                name: true
                            }
                        }
                    }
                },
                rxInvestigation: {
                    include: {
                        investigations: {
                            select: {
                                name: true
                            }
                        }
                    }
                },
                rxAdvice: {
                    include: {
                        advice: {
                            select: {
                                name: true
                            }
                        }

                    }
                },
                rxMedicine: {
                    include: {
                        medicine: {
                            select: {
                                medicineName: true
                            }
                        }

                    }
                }    
            }
        })
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.create = async(req, res, next) => {
    try {
        let {patientId, rxDate, followUp,chiefComplaintsList, examinationList, rxInvestigationList, diagnosisList, rxAdviceList, medicineList} = req.body;
        // console.log(req.body.chiefComplaintsList)
        let result = await prisma.rxMedicineParent.create({
            data: {
                patientId, rxDate:new Date(rxDate).toLocaleDateString(), followUp,activeStatus:1,
                rxMedicine: {
                    create: medicineList
                },
                rxComplaints: { 
                    create: chiefComplaintsList
                },
                rxExaminations: {
                    create: examinationList
                },
                rxDiagnosis: {
                    create: diagnosisList
                },
                rxInvestigation: {
                    create: rxInvestigationList
                },
                rxAdvice: {
                    create: rxAdviceList
                }
            }
        })

        // const upInfo = await prisma.patientAppoinInfo.update({
        //     where: {
        //         patientId: result.id
        //     },
        //     data:{
        //         patientAppintSatus: 2
        //     }
        // })
        res.json({ success: true, "message": "Save successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.statusChange = async(req, res, next) => {
    try {

        const upInfo = await prisma.patientAppoinInfo.updateMany({
            where: {
                patientInfoId: req.params.id
            },
            data:{
                patientAppintSatus: 2
            }
        })
        res.json({ success: true, "message": "Save successfully", upInfo})      
    } catch (error) {
        next(error)
    }
}

exports.getRxInformationByPatients = async(req, res, next) => {
    try {

        const result = await prisma.rxMedicineParent.findMany({
            where: {
                id: req.params.id
            },
            include: {
                rxMedicine: {
                    include: {
                        medicine:{
                            select:{
                                medicineName: true
                            } 
                        }
                    }

                },
                rxComplaints: {
                        include: {
                            chiefComplaints: {
                                select: {
                                    name: true
                                }
                            }
                        }
                    }
                
            }
        })
        res.json({ success: true, "message": "Show successfully", result})
        
    } catch (error) {
        next(error)
    }
}

exports.update = async(req, res, next) => {
    try {
        let {name, slNo, description,activeStatus} = req.body;
        let result = await prisma.advice.update({
            where: {
                id: req.params.id
            },
            data: {
                name, slNo, description,activeStatus
            }
        })
        res.json({ success: true, "message": "Update successfully", result})    

    } catch (error) {
        next(error)        
    }
}



exports.deleteAdvice = async(req, res, next) => {
    try {    
        let result = await prisma.advice.delete({
            where: {
                id: req.params.id
            }
        })
        res.json({ success: true, "message": "Delete successfully", result})        
    } catch (error) {
        next(error)        
    }
}
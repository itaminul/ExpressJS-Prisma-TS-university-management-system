const prisma = require('../../prisma/connection')
const session = require('express-session')

exports.getAll = async(req, res, next) => {
    try {                
        // console.log("session.username", req.session.name)
         console.log("sessionID",req.userInfo)
        // res.send('ddd')

        let result = await prisma.category.findMany()
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
       next(error)        
    }
}

exports.create = async(req, res, next) => {
    try {
        console.log("aaaaa bbbb", req.userInfo)

        let {categoryName, description,shortName, slNo} = req.body;

        let result = await prisma.category.create({
            data: {
                categoryName,
                description,
                shortName,
                slNo,
                // orgId: req.userInfo.orgId, 
                // createdBy: req.userInfo.userId
            }
        })

        res.json({ success: true, "message": "Save successfully", result})   

    } catch (error) {
        next(error)        
    }
}

exports.update = async(req, res, next) => {
    try {
        let {categoryName, shortName, description,slNo,activeStatus} = req.body;
        let result = await prisma.category.update({
            where: {
                id: req.params.id
            },

            data: {
                categoryName, shortName, description,slNo,activeStatus
                // updatedBy: req.user.userId
            }
        })
        res.json({ success: true, "message": "Update successfully", result})    

    } catch (error) {
        next(error)        
    }
}

exports.deleteCategory = async(req, res, next) => {
    try {    
        let result = await prisma.category.delete({
            where: {
                id: req.params.id
            }
        })
        res.json({ success: true, "message": "Delete successfully", result})        
    } catch (error) {
        next(error)        
    }
}
const prisma = require('../../prisma/connection')

exports.getAll = async(req, res, next) => {
    try {
        let result = await prisma.advice.findMany()
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.create = async(req, res, next) => {
    try {
        let {name, slNo, description} = req.body;
        let result = await prisma.advice.create({
            data: {
                name, slNo,description,activeStatus:1
            }
        })
        res.json({ success: true, "message": "Save successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.update = async(req, res, next) => {
    try {
        let {name, slNo, description,activeStatus} = req.body;
        let result = await prisma.advice.update({
            where: {
                id: req.params.id
            },
            data: {
                name, slNo, description,activeStatus
            }
        })
        res.json({ success: true, "message": "Update successfully", result})    

    } catch (error) {
        next(error)        
    }
}


exports.deleteAdvice = async(req, res, next) => {
    try {    
        let result = await prisma.advice.delete({
            where: {
                id: req.params.id
            }
        })
        res.json({ success: true, "message": "Delete successfully", result})        
    } catch (error) {
        next(error)        
    }
}
const prisma = require('../../prisma/connection')

exports.getAll = async(req, res, next) => {
    try {
        const result = await prisma.medicineGeneric.findMany()
        res.json({ success: true, "message": "Show successfully", result})   
    } catch (error) {
        next(error)
    }
}

exports.create = async(req, res, next) => {
    try {
        const{genericName,slNo,description} = req.body
        const result = await prisma.medicineGeneric.create({
            data: {
                genericName,slNo,description,activeStatus:1
            }
         })     
         res.json({ success: true, "message": "Create successfully", result})      
    } catch (error) {
        next(error)
        
    }
}




exports.update = async(req, res, next) => {
    try {
        const{genericName,slNo,description,activeStatus} = req.body
        const result = await prisma.medicineGeneric.update({
            where: {
                id: req.params.id
            },
            data: {
                genericName,slNo,description,activeStatus
            }
         })      
         res.json({ success: true, "message": "Update successfully", result})     
    } catch (error) {
        next(error)
        
    }
}


exports.deleteDiagnosis = async(req, res, next) => {
    try {    
        let result = await prisma.medicineGeneric.delete({
            where: {
                id: req.params.id
            }
        })
        res.json({ success: true, "message": "Delete successfully", result})        
    } catch (error) {
        next(error)        
    }
}
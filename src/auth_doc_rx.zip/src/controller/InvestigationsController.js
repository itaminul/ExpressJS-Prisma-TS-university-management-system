const prisma = require('../../prisma/connection')

exports.getAll = async(req, res, next) => {
    try {
        let result = await prisma.investigations.findMany()
        res.json({ success: true, "message": "Show successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.create = async(req, res, next) => {
    try {
        let {name, description, slNo} = req.body;
        let result = await prisma.investigations.create({
            data: {
                name, description, slNo,activeStatus: 1
            }
        })
        res.json({ success: true, "message": "Save successfully", result})        
    } catch (error) {
        next(error)        
    }
}

exports.update = async(req, res, next) => {
    try {
        let {name, description, slNo,activeStatus } = req.body;
        let result = await prisma.investigations.update({
            where: {
                id: req.params.id
            },
            data: {
                name, description, slNo,activeStatus 
            }
        })
        res.json({ success: true, "message": "Update successfully", result})    

    } catch (error) {
        next(error)        
    }
}


exports.deleteInvestigations = async(req, res, next) => {
    try {    
        let result = await prisma.investigations.delete({
            where: {
                id: req.params.id
            }
        })
        res.json({ success: true, "message": "Delete successfully", result})        
    } catch (error) {
        next(error)        
    }
}